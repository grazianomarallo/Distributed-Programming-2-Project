/**
 * 
 */
package it.polito.dp2.NFV.sol3.client1;

import it.polito.dp2.NFV.NffgReader;
import it.polito.dp2.NFV.NodeReader;

import java.util.*;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class NffgReaderClass implements NffgReader {
	private Calendar deployTime;
	private String name;
	private Map<String, NodeReader> nodes;

	public NffgReaderClass() {
		nodes = new HashMap<>();
	}

	public void setDeployTime(Calendar deployTime) {
		this.deployTime = deployTime;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNode(NodeReader node) {
		this.nodes.put(node.getName(), node);
	}

	@Override
	public Calendar getDeployTime() {
		return this.deployTime;
	}

	@Override
	public Set<NodeReader> getNodes() {
		Set<NodeReader> nodeReaders = new HashSet<>();
		for (NodeReader nodeReader : this.nodes.values()) {
			nodeReaders.add(nodeReader);
		}
		return nodeReaders;
	}

	@Override
	public NodeReader getNode(String s) {
		return this.nodes.get(s);
	}

	@Override
	public String getName() {
		return this.name;
	}
}



