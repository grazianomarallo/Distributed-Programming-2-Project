/**
 *
 */
package it.polito.dp2.NFV.sol1;

import it.polito.dp2.NFV.NfvReader;
import it.polito.dp2.NFV.NfvReaderException;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class NfvReaderFactory extends it.polito.dp2.NFV.NfvReaderFactory {


	public static NfvReaderFactory newInstance(){
		return new NfvReaderFactory();
	}


	@Override
	public NfvReader newNfvReader() throws NfvReaderException {
		return new NfvReaderClass();
	}

}
