package it.polito.dp2.NFV.sol1;

import static javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;

import java.io.File;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Set;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.MarshalException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import it.polito.dp2.NFV.NfvReaderFactory;
import org.xml.sax.SAXException;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.sol1.jaxb.*;


public class NfvInfoSerializer {
	private NfvReader monitor;
	private Network network;
	private ObjectFactory of;
	private static NfvInfoSerializer wf;
	private static String file;


	public NfvInfoSerializer() throws NfvReaderException {
		of = new ObjectFactory();
		network = of.createNetwork();
		monitor = NfvReaderFactory.newInstance().newNfvReader();
	}

	public static void main(String[] args) throws Exception {

		try {
			file = args[0]; //pass the file as the first argument on the command line
			wf = new NfvInfoSerializer();	//create a new object of infoserializer
			wf.marshalALL(); //marshal all the type

		} catch (NfvReaderException e) {
			System.err.println("Could not instantiate data generator.");
			e.printStackTrace();
			System.exit(1);
		}
	}

	public void marshalALL() throws DatatypeConfigurationException{
		marshalNFFG();
		marshalHost();
		marshalVNF();
		marshalConnection();
		JAXBContext jc;
		Schema schema;
		try {
			/**
			 * Instanciate the JAXBContext, the schema passing the xsd file and set the Marshaller
			 */
			jc = JAXBContext.newInstance( "it.polito.dp2.NFV.sol1.jaxb");
			Marshaller u = jc.createMarshaller();
			schema = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI).newSchema(new File("xsd/nfvInfo.xsd"));
			u.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			u.setSchema(schema);
			u.marshal(of.createNetwork(network), new File(file));
		}
		catch (MarshalException m){
			m.printStackTrace();
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (NullPointerException n){
			n.printStackTrace();
		} catch (IllegalArgumentException i ){
			i.printStackTrace();
		}

	}

	/**
	 * Allows the Marshal for the NFFG elements
	 */
	public void marshalNFFG(){
		NFFGs nn = new NFFGs();
		//Get an instance of Calendar in order to pass it to the NfvReader monitor when getting the NFFG
		Calendar c = Calendar.getInstance();
		c.set(1000, 1, 3);
		Set<NffgReader> set = monitor.getNffgs(c);
		//Iterate the set of NFFG setting all the parameters
		for (NffgReader nffg_r: set) {
			//Create a new object of NFFG class
			NFFG nffg = new NFFG();
			nffg.setName(nffg_r.getName());
			nffg.setDeployTime(NfvInfoSerializer.createXMLGregCalendar((nffg_r.getDeployTime())));
			//Get the node associated to the nffg and iterate setting all parameters
			Set<NodeReader> nodes = nffg_r.getNodes();
			for(NodeReader nr: nodes){
				//Create a new Object of Node and VNF class
				Node n = new Node();
				VNF vnf = new VNF();
				//Set all params for the vnf and for the node
				vnf.setName(nr.getFuncType().getName());
				vnf.setType(Catalog.fromValue(nr.getFuncType().getFunctionalType().name()));
				vnf.setDiskStorage(nr.getFuncType().getRequiredStorage());
				vnf.setMemoryAmount(nr.getFuncType().getRequiredMemory());
				n.setName(nr.getName());
				n.setVNF(vnf);		//here set to the node the vnf previously filled with correct data
				n.setHostName(nr.getHost().getName());
				Set<LinkReader> link = nr.getLinks();
				//Iterate the Link reader and set to the new Object Link the params
				for(LinkReader lr: link){
					Link l = new Link();
					l.setName(lr.getName());
					l.setSrc(lr.getSourceNode().getName());
					l.setDst(lr.getDestinationNode().getName());
					n.getLink().add(l);
				}
				//Add the node to the nffg object
				nffg.getNode().add(n);
			}
			//Add the nffg to the nffgs object
			nn.getNFFG().add(nffg);
		}
		//Set the nffgs object to the network
		network.setNFFGs(nn);
	}

	public void marshalHost(){
		Hosts hosts = new Hosts();
		Set<HostReader> set = monitor.getHosts();
		//Iterate the host reader
		for(HostReader hostReader : set){
			//Create a new Host obj and set all params
			Host host= new Host();
			host.setName(hostReader.getName());
			host.setMaxNumberVFN(hostReader.getMaxVNFs());
			host.setMemoryAmount(hostReader.getAvailableMemory());
			host.setDiskStorage(hostReader.getAvailableStorage());
			Set<NodeReader> nodeSet = hostReader.getNodes();
			//Iterate the node reader
			for (NodeReader nr: nodeSet){
				//Create a new Node obj and set all params
				Node node = new Node();
				node.setName(nr.getName());
				node.setHostName(nr.getHost().getName());
				//Create a new VNF obj and set all params
				VNF vnf = new VNF();
				vnf.setDiskStorage(nr.getFuncType().getRequiredStorage());
				vnf.setMemoryAmount(nr.getFuncType().getRequiredMemory());
				vnf.setName(nr.getFuncType().getName());
				vnf.setType(Catalog.fromValue(nr.getFuncType().getFunctionalType().name()));
				node.setVNF(vnf);
				//Add the node to the host
				host.getNode().add(node);
			}
			//Add the host to the host set
			hosts.getHost().add(host);
		}
		//Add the hosts to the network
		network.setHosts(hosts);

	}

	public void marshalVNF(){
		VNFs vnfs = new VNFs();
		Set<VNFTypeReader> set = monitor.getVNFCatalog();
		//Iterate the VnfReader
		for(VNFTypeReader vnfTypeReader: set){
			//Create and set params for the new VNF obj
			VNF vnf = new VNF();
			vnf.setName(vnfTypeReader.getName());
			vnf.setType(Catalog.fromValue(vnfTypeReader.getFunctionalType().name()));
			vnf.setMemoryAmount(vnfTypeReader.getRequiredMemory());
			vnf.setDiskStorage(vnfTypeReader.getRequiredStorage());
			//Add the vnf to the set of vnfs
			vnfs.getVNF().add(vnf);
		}
		//Add the vnfs to the network
		network.setVNFs(vnfs);

	}

	public void marshalConnection() {
		Connections connections = new Connections();
		Set<HostReader> set = monitor.getHosts();
		//Iterate the host in nested loop to get source and destination one
		for (HostReader sri : set) {
			for (HostReader srj : set) {
				//Create and set params for the new Connection obj
				Connection connection = new Connection();
				ConnectionPerformanceReader connectionPerformanceReader = monitor.getConnectionPerformance(sri,srj);
				connection.setSrc(sri.getName());
				connection.setDst(srj.getName());
				connection.setLatency(connectionPerformanceReader.getLatency());
				connection.setAverageThroughput(connectionPerformanceReader.getThroughput());
				//Add the connection to the connections sets
				connections.getConnection().add(connection);
			}

		}
		//Add the connections to the network
		network.setConnections(connections);
	}




	public static XMLGregorianCalendar createXMLGregCalendar(Calendar calendar) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTimeInMillis(calendar.getTimeInMillis());
		XMLGregorianCalendar startTime = null;
		try {
			startTime = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		}
		catch (DatatypeConfigurationException e) {
			System.err.println("Error! There is a problem with the instantiation of the DatatypeFactory");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return startTime;
	}

	public static Calendar toCalendar(XMLGregorianCalendar calendar){
		Calendar c = calendar.toGregorianCalendar();
		return c;
	}

}
