@javax.xml.bind.annotation.XmlSchema(namespace = "http://pad.polito.it/dp2/Neo4JSimpleXML", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.polito.dp2.NFV.sol3.service.wjc;
