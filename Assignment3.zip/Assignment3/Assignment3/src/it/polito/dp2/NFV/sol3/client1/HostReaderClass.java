/**
 * 
 */
package it.polito.dp2.NFV.sol3.client1;

import it.polito.dp2.NFV.HostReader;
import it.polito.dp2.NFV.NodeReader;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class HostReaderClass implements HostReader {
	private int maxVNFs;
	private int availableMemory;
	private int availableStorage;
	private Map<String, NodeReader> nodes;
	private String name;

	public HostReaderClass() {
		nodes = new HashMap<>();
	}

	public void setMaxVNFs(int maxVNFs) {
		this.maxVNFs = maxVNFs;
	}

	public void setAvailableMemory(int availableMemory) {
		this.availableMemory = availableMemory;
	}

	public void setAvailableStorage(int availableStorage) {
		this.availableStorage = availableStorage;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNode(NodeReader node) {
		this.nodes.put(node.getName(), node);
	}

	@Override
	public int getMaxVNFs() {
		return this.maxVNFs;
	}

	@Override
	public int getAvailableMemory() {
		return this.availableMemory;
	}

	@Override
	public int getAvailableStorage() {
		return this.availableStorage;
	}

	@Override
	public Set<NodeReader> getNodes() {
		Set<NodeReader> nodeReaders = new HashSet<>();

		for (NodeReader nodeReader : this.nodes.values()) {
			nodeReaders.add(nodeReader);
		}
		return nodeReaders;
	}

	@Override
	public String getName() {
		return this.name;
	}
}
