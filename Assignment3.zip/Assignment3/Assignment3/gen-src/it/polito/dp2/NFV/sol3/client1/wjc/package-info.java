@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/Assignment3/")
package it.polito.dp2.NFV.sol3.client1.wjc;
