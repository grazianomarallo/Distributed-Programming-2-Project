package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.lab3.ServiceException;
import it.polito.dp2.NFV.sol3.client2.wjc.*;
import it.polito.dp2.NFV.sol3.client2.wjc.NFFGs;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.*;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:25/02/2018
 */
public class Client2 implements it.polito.dp2.NFV.NfvReader {
    private WebTarget target;
    private Map<String, HostReaderClass> hostsMap;
    private Map<String, VNFReaderClass> VNFsMap;
    private Map<String, ConnectionPerformanceReaderClass> connectionsMap;
    private Map<String, NodeReaderClass> nodesMap;
    private Map<String, LinkReaderClass> linksMap;
    private Map<String, NffgReaderClass> nffgsMap;
    private Client client;

    public Client2() {
        client = ClientBuilder.newClient();
        target = client.target(getBaseURI());
        hostsMap = new HashMap<>();
        VNFsMap = new HashMap<>();
        connectionsMap = new HashMap<>();
        nodesMap = new HashMap<>();
        linksMap = new HashMap<>();
        nffgsMap = new HashMap<>();



        loadCatalog();
        loadHosts();
        loadNffgs();

    }


    private void loadNffgs() {
        NFFGs nffgs;

        Response response = target.path("/service/nffgs")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        nffgs = response.readEntity(NFFGs.class);

        for (NFFG nffg : nffgs.getNFFG()) {
           NffgReaderClass nffgReaderClass = new NffgReaderClass();
            Calendar calendar = nffg.getDeployTime().toGregorianCalendar();

            Calendar cal = Calendar.getInstance();
            cal.setTimeZone(calendar.getTimeZone());
            cal.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
            cal.set(Calendar.MONTH, calendar.get(Calendar.MONTH));
            cal.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
            cal.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
            cal.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
            cal.set(Calendar.SECOND, calendar.get(Calendar.SECOND));
            cal.set(Calendar.MILLISECOND, calendar.get(Calendar.MILLISECOND));

            nffgReaderClass.setDeployTime(cal);
            nffgReaderClass.setName(nffg.getName());

            for (Node node : nffg.getNodes().getNode()) {
                NodeReaderClass nodeReaderClass = new NodeReaderClass();

                nodeReaderClass.setName(node.getName());
                nodeReaderClass.setFunction_type(VNFsMap.get(node.getNameVnf()));
                nodeReaderClass.setHost(hostsMap.get(node.getAllocatedOn()));

                hostsMap.get(nodeReaderClass.getHost().getName()).setNode(nodeReaderClass);

                nodesMap.put(nodeReaderClass.getName(), nodeReaderClass);
                nodeReaderClass.setNffg(nffgReaderClass);
                nffgReaderClass.setNode(nodeReaderClass);
            }

            for (Link link : nffg.getLinks().getLink()) {
              LinkReaderClass linkReaderClass = new LinkReaderClass();

                linkReaderClass.setName(link.getName());
                linkReaderClass.setLatency(link.getMaxLatency().intValue());
                linkReaderClass.setThroughput(link.getMinThroughput());
                linkReaderClass.setSourceNode(nodesMap.get(link.getSrc()));
                linkReaderClass.setDestinationNode(nodesMap.get(link.getDst()));

                nodesMap.get(link.getSrc()).setLink(linkReaderClass);
                nodesMap.get(link.getSrc()).setNffg(nffgReaderClass);
                nodesMap.get(link.getDst()).setNffg(nffgReaderClass);
                hostsMap.get(linkReaderClass.getSourceNode().getHost().getName()).setNode(nodesMap.get(link.getSrc()));
                hostsMap.get(linkReaderClass.getDestinationNode().getHost().getName()).setNode(nodesMap.get(link.getDst()));
                linksMap.put(linkReaderClass.getName(), linkReaderClass);

                nffgReaderClass.setNode(nodesMap.get(link.getSrc()));
                nffgReaderClass.setNode(nodesMap.get(link.getDst()));
            }

            nffgsMap.put(nffgReaderClass.getName(), nffgReaderClass);
        }
    }

    private void loadCatalog() {
        VNFs vnfs;

        Response response = target.path("/service/catalog")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        vnfs = response.readEntity(VNFs.class);

        for (VNF vnf : vnfs.getVNF()) {
            VNFReaderClass vnfReaderClass = new VNFReaderClass();
            vnfReaderClass.setName(vnf.getName());
            vnfReaderClass.setFunctional_type(FunctionalType.fromValue(vnf.getType()));
            vnfReaderClass.setRequiredMemory(vnf.getMemoryAmount().intValue());
            vnfReaderClass.setRequiredStorage(vnf.getDiskStorage().intValue());

            VNFsMap.put(vnfReaderClass.getName(), vnfReaderClass);
        }

    }

    private void loadHosts() {
        Hosts hosts;

        Response response = target.path("/service/hosts")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        hosts = response.readEntity(Hosts.class);

        for (Host host : hosts.getHost()) {
           HostReaderClass hostReaderClass = new HostReaderClass();
            hostReaderClass.setName(host.getName());
            hostReaderClass.setAvailableMemory(host.getMemoryAmount().intValue());
            hostReaderClass.setAvailableStorage(host.getDiskStorage().intValue());
            hostReaderClass.setMaxVNFs(host.getMaxNumberVFN().intValue());
            hostsMap.put(hostReaderClass.getName(), hostReaderClass);
        }

        Connections connections;

        response = target.path("/service/connections")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        connections = response.readEntity(Connections.class);

        for (Connection connection : connections.getConnection()) {
            ConnectionPerformanceReaderClass performanceReader = new ConnectionPerformanceReaderClass();
            performanceReader.setName(connection.getSrc() + "_" + connection.getDst());
            performanceReader.setLatency(connection.getAvarageLatency().intValue());
            performanceReader.setThroughput(connection.getAverageThroughput());
            connectionsMap.put(connection.getSrc() + "_" + connection.getDst(), performanceReader);
        }

    }


    @Override
    public Set<NffgReader> getNffgs(Calendar calendar) {
        Set<NffgReader> nffgReaders = new HashSet<>();
        if (calendar == null) {
            nffgReaders.addAll(nffgsMap.values());
            return nffgReaders;
        }
        for (NffgReader nffgReader : nffgsMap.values()) {
            if (nffgReader.getDeployTime().equals(calendar) || nffgReader.getDeployTime().after(calendar)) {
                nffgReaders.add(nffgReader);
            }
        }

        return nffgReaders;
    }

    @Override
    public NffgReader getNffg(String s) {
        return this.nffgsMap.get(s);
    }

    @Override
    public Set<HostReader> getHosts() {
        Set<HostReader> hostReaders = new HashSet<>();
        for (HostReader hostReader : hostsMap.values()) {
            hostReaders.add(hostReader);
        }

        return hostReaders;
    }

    @Override
    public HostReader getHost(String s) {
       return this.hostsMap.get(s);
    }

    @Override
    public Set<VNFTypeReader> getVNFCatalog() {
        Set<VNFTypeReader> vnfTypeReaders = new HashSet<>();
        vnfTypeReaders.addAll(VNFsMap.values());

        return vnfTypeReaders;

    }

    @Override
    public ConnectionPerformanceReader getConnectionPerformance(HostReader hostReader, HostReader hostReader1) {
        return this.connectionsMap.get(hostReader.getName() + "_" + hostReader1.getName());
    }


    private static URI getBaseURI() {
        return UriBuilder.fromUri(System.getProperty(
                "it.polito.dp2.NFV.lab3.URL",
                "http://localhost:8080/NfvDeployer/rest")).build();
    }

    private void checkResponse(Response R) throws ServiceException {
        switch (R.getStatus()) {
            case 400:
                throw new ServiceException("ServiceException: Bad Request on NfvDeployer service (Client2)");

            case 404:
                throw new ServiceException("ServiceException: Not Found on NfvDeployer service (Client2)");

            case 500:
                throw new ServiceException("ServiceException: Internal Server Error on NfvDeployer service (Client2)");

            default:
                break;
        }
    }
}
