
package it.polito.dp2.NFV.sol3.client2.wjc;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nameNffg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nameVnf" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="allocatedOn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="name" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "nameNffg",
    "nameVnf",
    "allocatedOn"
})
@XmlRootElement(name = "Node")
public class Node {

    protected String nameNffg;
    @XmlElement(required = true)
    protected String nameVnf;
    protected String allocatedOn;
    @XmlAttribute(name = "name")
    protected String name;

    /**
     * Gets the value of the nameNffg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameNffg() {
        return nameNffg;
    }

    /**
     * Sets the value of the nameNffg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameNffg(String value) {
        this.nameNffg = value;
    }

    /**
     * Gets the value of the nameVnf property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNameVnf() {
        return nameVnf;
    }

    /**
     * Sets the value of the nameVnf property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNameVnf(String value) {
        this.nameVnf = value;
    }

    /**
     * Gets the value of the allocatedOn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllocatedOn() {
        return allocatedOn;
    }

    /**
     * Sets the value of the allocatedOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllocatedOn(String value) {
        this.allocatedOn = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

}
