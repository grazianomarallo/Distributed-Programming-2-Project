/**
 * 
 */
package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.ConnectionPerformanceReader;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class ConnectionPerformanceReaderClass implements ConnectionPerformanceReader {
	private String name;
	private float throughput;
	private int latency;

	public ConnectionPerformanceReaderClass() {

	}

	public void setName(String name) {
		this.name = name;
	}

	public void setThroughput(float throughput) {
		this.throughput = throughput;
	}

	public void setLatency(int latency) {
		this.latency = latency;
	}

	@Override
	public float getThroughput() {
		return this.throughput;
	}

	@Override
	public int getLatency() {
		return this.latency;
	}
}
