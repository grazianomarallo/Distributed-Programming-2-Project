package it.polito.dp2.NFV.sol3.service;


import it.polito.dp2.NFV.NfvReader;
import it.polito.dp2.NFV.NfvReaderException;
import it.polito.dp2.NFV.NfvReaderFactory;
import it.polito.dp2.NFV.sol3.service.xjc.*;
import org.apache.commons.lang.NotImplementedException;


import javax.inject.Singleton;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.*;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.math.BigInteger;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:24/02/2018
 */
@Singleton
@Path("/service/")
public class NfvDeployer  {

    private static NfvReader monitor;
    private static Reader reader;
    private static NeoService neoService;
    private final ReentrantReadWriteLock lockRW;
    private final Lock lockR;
    private final Lock lockW;

    private ConcurrentMap<String, NFFG> loadedNffgs;
    private ConcurrentMap<String, Node> loadedNodes;
    private ConcurrentMap<String, Link> loadedLinks;
    private ConcurrentMap<String, Host> loadedHosts;
    private ConcurrentMap<String, Connection> loadedConnections;
    private ConcurrentMap<String, VNF> loadedVNFs;
    private ConcurrentMap<String, List<String>> allocatedNodes; //nodes allocated on hosts
    private ConcurrentMap<String, List<String>> incomingLinks;
    private ConcurrentMap<String, List<String>> outgoingLinks;
    private AtomicInteger incrementNffg;
    private AtomicInteger incrementNode;

    public static NfvReader getMonitor() {
        return monitor;
    }
    public static Reader getReader() {
        return reader;
    }

    public NfvDeployer() throws DatatypeConfigurationException {
        NfvReaderFactory factory = NfvReaderFactory.newInstance();
        try {
            monitor = factory.newNfvReader();
        } catch (NfvReaderException e) {
            System.err.println("ERROR: Cannot instantiate NfvReaderFactory in NfvDeployer");
            e.printStackTrace();
        }

        reader = new Reader();
        neoService = reader.getNeoService();

        //Initialize lock for read and write operation and ensure atomic operation
        lockRW = new ReentrantReadWriteLock();
        lockR = lockRW.readLock();
        lockW = lockRW.writeLock();

        //Load the Nffg0 and all the informations needed
        reader.loadVNFs();
        reader.loadHosts();
        reader.loadNffg();
        reader.loadConnections();

        //retrieve all the maps already filled by the Reader
        loadedNffgs = reader.getLoadedNffgs();
        loadedNodes = reader.getLoadedNodes();
        loadedLinks = reader.getLoadedLinks();
        loadedHosts= neoService.getLoadedHosts();
        loadedConnections= reader.getLoadedConnections();
        loadedVNFs = reader.getLoadedVNFs();
        allocatedNodes = neoService.getAllocatedNodes();
        incomingLinks = reader.getIncomingLinks();
        outgoingLinks = reader.getOutgoingLinks();
        incrementNffg = reader.getIncrementNffg();
        incrementNode = reader.getIncrementNode();


    }

    /**
     * Retrieve all the nffgs that have been loaded
     * @return nffgs items containing all the nffgs
     */
    @GET
    @Path("nffgs")
    @Produces(MediaType.APPLICATION_XML)
    public NFFGs getNFFGs() {
        NFFGs nffgs = new NFFGs();
        lockR.lock();
        try {
            for (NFFG nffg : loadedNffgs.values()) {
                nffgs.getNFFG().add(nffg);
            }
        } finally {
            lockR.unlock();
        }
        return nffgs;
    }

    /**
     * Post a new new nffg into the service performing and checking all the required
     * option
     * @param nffg
     * @return the loaded nffg
     * @throws DatatypeConfigurationException
     */
    @POST
    @Path("nffgs")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public NFFG postNFFG(NFFG nffg) throws DatatypeConfigurationException {
        //validate input received from the client
        performMarshall(NFFG.class,nffg);

        nffg.setName("Nffg" + incrementNffg.toString());
        Integer allocated = 0;
        Nodes nodes = new Nodes();
        lockW.lock();
        try {
            if (nffg.getNodes() != null) {
                for (Node node : nffg.getNodes().getNode()) {
                    node.setNameNffg(nffg.getName());
                    node.setName("Node" + incrementNode.toString());
                    if (node.getAllocatedOn() == null) {
                        try {
                            if (!seekHost_AllocNode(node)) {
                                iterateAndRemoveNode(nffg,allocated,node);
                                throw new ForbiddenException();
                            }
                        } catch (ServiceException S) {
                            iterateAndRemoveNode(nffg,allocated,node);
                            throw new InternalServerErrorException();
                        }
                    } else {
                        if (!loadedHosts.containsKey(node.getAllocatedOn())) throw new NotFoundException();
                        try {
                            if (!canAllocate(node.getAllocatedOn(), node)) {
                                if (!seekHost_AllocNode(node)) {
                                    for (Node node1 : nffg.getNodes().getNode()) {
                                        if (allocated == 0) break;
                                        removeNodeFromHost(node1.getAllocatedOn(), node1);
                                        incomingLinks.remove(node.getName());
                                        outgoingLinks.remove(node.getName());
                                        allocated--;
                                    }

                                    throw new ForbiddenException();
                                }
                            }
                        } catch (ServiceException S) {
                            iterateAndRemoveNode(nffg,allocated,node);
                            throw new InternalServerErrorException();
                        }
                    }

                    allocated++;
                    incrementNode.incrementAndGet();
                    incomingLinks.put(node.getName(), new CopyOnWriteArrayList<String>());
                    outgoingLinks.put(node.getName(), new CopyOnWriteArrayList<String>());
                    loadedNodes.put(node.getName(), node);
                    nodes.getNode().add(node);
                }
            }

            nffg.setDeployTime(getXMLGregorianCalendarNow());

            incrementNffg.incrementAndGet();

            loadedNffgs.put(nffg.getName(), nffg);

            Links links = new Links();

            loadedNffgs.get(nffg.getName()).setNodes(nodes);
            loadedNffgs.get(nffg.getName()).setLinks(links);


            return nffg;


        } finally {
            lockW.unlock();
        }

    }

    /**
     * Retrieves all the node of the specified NFFG
     * @param id
     * @return a Nodes object
     */
    @GET
    @Path("nffgs/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    public Nodes getNFFGNodes(@PathParam("id") String id) {
        Nodes nodes;
        lockR.lock();
        try {
            if (!loadedNffgs.containsKey(id) || id == null || id.trim().length() == 0) {
                throw new NotFoundException();
            }
            nodes = loadedNffgs.get(id).getNodes();

        } finally {
            lockR.unlock();
        }
        return nodes;

    }

    /**
     * Post a node on the specified nffg
     * @param node  the node to post
     * @param id the nffg id name
     * @param suggest the name of the suggest host on which allocate the node
     * @return a node object
     */
    @POST
    @Path("nffgs/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public Node postNFFGNodes(Node node, @PathParam("id") String id,
                               @DefaultValue("no")
                               @QueryParam("suggestedHost") String suggest) {
        performMarshall(Node.class,node);

        lockW.lock();

        try {

            if (!loadedNffgs.containsKey(id)) {
                throw new NotFoundException();
            }

            if (suggest.equals("yes") && node.getAllocatedOn() == null) {
                throw new BadRequestException();
            }

            if (suggest.equals("yes") && !loadedHosts.containsKey(node.getAllocatedOn())) {
                throw new NotFoundException();
            }

            node.setName("Node" + incrementNode.toString());
            node.setNameNffg(id);

            try {
                if (suggest.equals("no")) {
                    if (!seekHost_AllocNode(node)) {
                        throw new ForbiddenException();
                    }
                } else {
                    if (!canAllocate(node.getAllocatedOn(), node)) {
                        if (!seekHost_AllocNode(node)) {
                            throw new ForbiddenException();
                        }
                    }
                }
            } catch (ServiceException S) {
                throw new InternalServerErrorException();
            }

            loadedNffgs.get(id).getNodes().getNode().add(node);
            incomingLinks.put(node.getName(), new CopyOnWriteArrayList<String>());
            outgoingLinks.put(node.getName(), new CopyOnWriteArrayList<String>());
            incrementNode.incrementAndGet();

            return node;
        } finally {
            lockW.unlock();
        }

    }

    /**
     * Retrieves a specif node on a nffg
     * @param id name id of the nffg
     * @param id2 name of the node
     * @return the requested node
     */
    @GET
    @Path("nffgs/{id}/nodes/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Node getNFFGNode(@PathParam("id") String id, @PathParam("id2") String id2) {
        lockR.lock();
        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }
            return loadedNodes.get(id2);
        } finally {
            lockR.unlock();
        }

    }

    /**
     * Delete the node from the nffg
     * @param id nffg name
     * @param id2 node name
     * @return an exception (NOT IMPLEMENTED)
     */
    @DELETE
    @Path("nffgs/{id}/nodes/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Node deleteNFFGNode(@PathParam("id") String id, @PathParam("id2") String id2) {
        throw new NotImplementedException();

    }

    /**
     * Retrives all the link for the considered nffg
     * @param id
     * @return
     */
    @GET
    @Path("nffgs/{id}/links")
    @Produces(MediaType.TEXT_XML)
    public Links getNFFGLinks(@PathParam("id") String id) {

        Links links;
        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id)) {
                throw new NotFoundException();
            }
            links = loadedNffgs.get(id).getLinks();
        } finally {
            lockR.unlock();
        }

        return links;

    }

    /**
     * Retrieves the link on the nffg
     * @param id name of the nffg
     * @param id2 name of the link
     * @return the requested link
     */
    @GET
    @Path("nffgs/{id}/links/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Link getNFFGLink(@PathParam("id") String id,  @PathParam("id2") String id2) {

        Link link;
        lockR.lock();


        try {
            if (!loadedNffgs.containsKey(id) || !loadedLinks.containsKey(id2)
                    || !loadedNodes.get(loadedLinks.get(id2).getSrc()).getNameNffg().equals(id)
                    || !loadedNodes.get(loadedLinks.get(id2).getDst()).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }
            link = loadedLinks.get(id2);
        } finally {
            lockR.unlock();
        }

        return link;

    }

    /**
     * Delete the link on the nffg
     * @param id nffg name
     * @param id2 node name
     * @return an exception
     */
    @DELETE
    @Path("nffgs/{id}/links/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Link deleteNFFGLink(@PathParam("id") String id,
                                 @PathParam("id2") String id2) {
        throw new NotImplementedException();
    }

    /**
     * Post the link on the nffg
     * @param id nffg name
     * @param link link name
     * @param overwrite boolan value default no
     * @return the link
     */
    @POST
    @Path("nffgs/{id}/links")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public Link postNFFGLink(@PathParam("id") String id, Link link,
                               @DefaultValue("false")
                               @QueryParam("overwrite") String overwrite) {
        performMarshall(Link.class,link);
        lockW.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(link.getSrc())
                    || !loadedNodes.containsKey(link.getDst())
                    || !loadedNodes.get(link.getSrc()).getNameNffg().equals(id)
                    || !loadedNodes.get(link.getDst()).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            if (overwrite.equals("false") && loadedLinks.containsKey(link.getSrc() + "_" + link.getDst())) {
                throw new ForbiddenException();
            }

            if (overwrite.equals("true")) {
                link.setName(link.getSrc() + "_" + link.getDst());
                loadedLinks.put(link.getName(), link);
                return link;
            }

            link.setName(link.getSrc() + "_" + link.getDst());
            if (link.getMinThroughput() == null) link.setMinThroughput(Float.valueOf(0));
            if (link.getMaxLatency() == null) link.setMaxLatency(BigInteger.valueOf(0));


            try {
                neoService.loadNeoLink(link);
            } catch (ServiceException S) {
                throw new InternalServerErrorException();
            }

            loadedLinks.put(link.getSrc() + "_" + link.getDst(), link);
            outgoingLinks.get(link.getSrc()).add(link.getName());
            incomingLinks.get(link.getDst()).add(link.getName());
            loadedNffgs.get(id).getLinks().getLink().add(link);

            return link;

        } finally {
            lockW.unlock();
        }

    }

    /**
     * Retrieves the reachable Host on the specified node
     * @param id nffg name
     * @param id2 node name
     * @return the reachable hosts
     */
    @GET
    @Path("nffgs/{id}/nodes/{id2}/reachableHosts")
    @Produces(MediaType.APPLICATION_XML)
    public Hosts getReachableHost_Node(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Response res = neoService.target.path("/data/node/" +
                    neoService.getNeoNodeMap().get(id2) + "/reachableNodes")
                    .queryParam("relationshipTypes", "AllocatedOn|ForwardsTo")
                    .queryParam("nodeLabel","Host")
                    .request(MediaType.APPLICATION_XML)
                    .accept(MediaType.APPLICATION_XML)
                    .get();


            try {
                neoService.checkResponse(res);
            } catch (ServiceException e) {
                e.printStackTrace();
            }

            it.polito.dp2.NFV.sol3.service.wjc.Nodes myReachableNodes = res.readEntity(it.polito.dp2.NFV.sol3.service.wjc.Nodes.class);
            Hosts hosts = new Hosts();
            for (it.polito.dp2.NFV.sol3.service.wjc.Nodes.Node node : myReachableNodes.getNode()) {
                Host host;
                host = loadedHosts.get(node.getProperties().getProperty().get(0).getValue());

                hosts.getHost().add(host);
            }

            return hosts;
        } finally {
            lockR.unlock();
        }

    }

    /**
     * Retrieves the incoming link for the nodes of the nffg specified
     * @param id nffg name
     * @param id2 node name
     * @return the links
     */
    @GET
    @Path("nffgs/{id}/nodes/{id2}/links/in")
    @Produces(MediaType.APPLICATION_XML)
    public Links getIncomingLinks_Node(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Links links = new Links();

            for (String string : incomingLinks.get(id2)) {
                links.getLink().add(loadedLinks.get(string));
            }

            return links;
        } finally {
            lockR.unlock();
        }
    }


    /**
     * Retrieves the outgoing link for the nodes of the nffg specified
     * @param id nffg name
     * @param id2 node name
     * @return the links
     */
    @GET
    @Path("nffgs/{id}/nodes/{id2}/links/out")
    @Produces(MediaType.APPLICATION_XML)
    public Links getOutcomingLinks_Node(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Links links = new Links();

            for (String string : outgoingLinks.get(id2)) {
                links.getLink().add(loadedLinks.get(string));
            }

            return links;
        } finally {
            lockR.unlock();
        }

    }


    /**
     * Iterate all the node inside the current nffg and if condition is not verified remove the current
     * node from all the map
     * @param nffg
     * @param allocated
     * @param n
     */
    private void iterateAndRemoveNode(NFFG nffg, Integer allocated, Node n) {
        for (Node node1 : nffg.getNodes().getNode()) {
            if (allocated == 0) break;
            removeNodeFromHost(node1.getAllocatedOn(), node1);
            allocatedNodes.get(n.getAllocatedOn()).remove(n.getName());
            incomingLinks.remove(n.getName());
            outgoingLinks.remove(n.getName());
            allocated--;
        }
    }


    /**
     * Retrieve the nffg with the correspondent id passed in the uri
     * @param id
     * @return the requested nffg
     */
    @GET
    @Path("nffgs/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public NFFG getNFFG(@PathParam("id") String id) {

        NFFG nffg;
        lockR.lock();
        try {
            if (!loadedNffgs.containsKey(id) || id == null || id.trim().length() == 0) {
                throw new NotFoundException();
            }
            nffg = loadedNffgs.get(id);
        } finally {
            lockR.unlock();
        }
        return  nffg;


    }

    /**
     * Delete the the nffg with the correspondent id passed in the uri
     * @param id
     * @return new exception here because method is not implemented
     */
    @DELETE
    @Path("nffgs/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public NFFG deleteNFFG(@PathParam("id") String id) {
        throw new NotImplementedException();

    }


    /**
     * Retrieve all the host that have been loaded
     * @return the hosts already lodead
     */
    @GET
    @Path("hosts")
    @Produces(MediaType.APPLICATION_XML)
    public Hosts getHosts() {
        lockR.lock();
        try {
            Hosts hosts = new Hosts();
            for (Host host : loadedHosts.values()) hosts.getHost().add(host);
            return hosts;
        } finally {
            lockR.unlock();
        }
    }

    /**
     * Retrieve the host with the correspondent id
     * @param id
     * @return
     */
    @GET
    @Path("hosts/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Host getHost(@PathParam("id") String id) {

        lockR.lock();

        try {
            if (!loadedHosts.containsKey(id)) throw new NotFoundException();

            return loadedHosts.get(id);
        } finally {
            lockR.unlock();
        }
    }

    @GET
    @Path("hosts/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    public Nodes getNodesAllocatedOnHostInXML(@PathParam("id") String id) {

        lockR.lock();

        try {
            if (!loadedHosts.containsKey(id)) throw new NotFoundException();

            Nodes nodes = new Nodes();
            for (String string : allocatedNodes.get(id)) nodes.getNode().add(loadedNodes.get(string));

            return nodes;
        } finally {
            lockR.unlock();
        }
    }


    /**
     * Retrieve all the connection that have been loaded
     * @return all the the connection
     */
    @GET
    @Path("connections")
    @Produces(MediaType.APPLICATION_XML)
    public Connections getConnections() {
        Connections connections = new Connections();
        for (Connection connection : loadedConnections.values()) connections.getConnection().add(connection);
        return connections;

    }

    /**
     * Retrieves a specifiction based on source and destination
     * @param src source
     * @param dst destination
     * @return the connection
     */
    @GET
    @Path("connections/connection")
    @Produces(MediaType.APPLICATION_XML)
    public Connection getConnectionInXML(@DefaultValue("none") @QueryParam("src") String src, @DefaultValue("none") @QueryParam("dst") String dst) {

        if (src.equals("none") || dst.equals("none") || !loadedConnections.containsKey(src + "_" + dst)) {
            throw new NotFoundException();
        }
        return loadedConnections.get(src + "_" + dst);
    }


    /**
     * Retrieve the entire catalog of VNF
     * @return the entire catalog
     */
    @GET
    @Path("catalog")
    @Produces(MediaType.APPLICATION_XML)
    public VNFs getCatalog() {
        VNFs VNFs = new VNFs();
        for (VNF V : loadedVNFs.values()) VNFs.getVNF().add(V);
        return VNFs;
    }

    /**
     * Retrieve the the correspondent VNF loaded by id
     * @param id
     * @return
     */
    @GET
    @Path("catalog/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public VNF getVNFFromCatalog(@PathParam("id") String id) {
        if (!loadedVNFs.containsKey(id)) throw new NotFoundException();
        return loadedVNFs.get(id);

    }


    //This method allow the Marshall of the object passed as parameter
    //in order to be sure that the client send the correct xml
    private void performMarshall(Class c, Object obj ){
        try {
            // create jaxb context
            JAXBContext jaxbContext = JAXBContext.newInstance(c);

            SchemaFactory sf = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);
            Schema schema = sf.newSchema(NfvDeployer.class.getResource("/xsd/NfvDeployer.xsd"));

            // create Marshaller using JAXB context
            Marshaller m = jaxbContext.createMarshaller();
            m.setSchema(schema);
            m.marshal(obj, System.out);

        } catch (JAXBException e) {
            e.printStackTrace();
            throw new BadRequestException();
        } catch (org.xml.sax.SAXException e) {
            e.printStackTrace();
            throw new BadRequestException();
        }


    }

    //Iterate all hosts and call the method @canAllocate in order to perform checks
    private boolean seekHost_AllocNode(Node node) throws ServiceException {
        for (String host : loadedHosts.keySet()) {
            if (canAllocate(host, node)) return true;
        }
        return false;
    }



    private boolean canAllocate(String host, Node node) throws ServiceException {
        BigInteger maxVnf = loadedHosts.get(host).getMaxNumberVFN();
        BigInteger hostMemory = loadedHosts.get(host).getMemoryAmount();
        BigInteger hostStorage =  loadedHosts.get(host).getDiskStorage();
        BigInteger vnfMemory = loadedVNFs.get(node.getNameVnf()).getMemoryAmount();
        BigInteger vnfStorage = loadedVNFs.get(node.getNameVnf()).getDiskStorage();

        /**
         * verify if is possibile to allocate the considered node onto the host.
         * If there is at least one spot empty for VNF allocation on the host &&
         * the host memory, host storage are free enough to store the node, this is
         * allocated on the considered host
         */
        if ((maxVnf.intValue() >= 1) && (hostMemory.intValue() >= vnfMemory.intValue()) && (hostStorage.intValue() >= vnfStorage.intValue())) {
            loadedHosts.get(host).setMaxNumberVFN(maxVnf.subtract(BigInteger.valueOf(1)));
            loadedHosts.get(host).setMemoryAmount(hostMemory.subtract(vnfMemory));
            loadedHosts.get(host).setDiskStorage(hostStorage.subtract(vnfStorage));
            node.setAllocatedOn(host);

            //try to load the allocated node onto neo4j service
            try {
                neoService.loadNeoNode(node);
            } catch (ServiceException S) {
                loadedHosts.get(host).setMaxNumberVFN(maxVnf.add(BigInteger.valueOf(1)));
                loadedHosts.get(host).setMemoryAmount(hostMemory.add(vnfMemory));
                loadedHosts.get(host).setDiskStorage(hostStorage.add(vnfStorage));
                throw new ServiceException();
            }
            neoService.loadNeoNode(node); //todo perchè?
            //update map to keep track of the allocation done
            loadedNodes.put(node.getName(), node);
            allocatedNodes.get(host).add(node.getName());
            return true;

        } else return false;
    }

    /**
     * Remove a node from a host either in maps and neo4j service
     * @param host name of the host
     * @param node Node object to remove
     */
    private void removeNodeFromHost(String host, Node node) {
        BigInteger maxVnf = loadedHosts.get(host).getMaxNumberVFN();
        BigInteger hostMemory = loadedHosts.get(host).getMemoryAmount();
        BigInteger hostStorage =  loadedHosts.get(host).getDiskStorage();
        BigInteger vnfMemory = loadedVNFs.get(node.getNameVnf()).getMemoryAmount();
        BigInteger vnfStorage = loadedVNFs.get(node.getNameVnf()).getDiskStorage();

        loadedHosts.get(host).setMaxNumberVFN(maxVnf.add(BigInteger.valueOf(1)));
        loadedHosts.get(host).setMemoryAmount(hostMemory.add(vnfMemory));
        loadedHosts.get(host).setDiskStorage(hostStorage.add(vnfStorage));

        try {
            Response response = neoService.target.path("/data/node/" + neoService.getNeoHostMap().get(node.getName()))
                    .request(MediaType.APPLICATION_XML)
                    .delete();

            try {
                neoService.checkResponse(response);
            } catch (ServiceException e) {
                e.printStackTrace();
            }

        } finally {
            allocatedNodes.get(host).remove(node.getName());

            loadedNodes.remove(node.getName());
            neoService.getNeoNodeMap().remove(node.getName());
        }
    }


    private XMLGregorianCalendar getXMLGregorianCalendarNow()
            throws DatatypeConfigurationException
    {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();
        return datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
    }




}
