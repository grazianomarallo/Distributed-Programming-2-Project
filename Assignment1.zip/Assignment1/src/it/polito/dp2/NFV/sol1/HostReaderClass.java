/**
 * 
 */
package it.polito.dp2.NFV.sol1;

import java.util.Set;

import it.polito.dp2.NFV.HostReader;
import it.polito.dp2.NFV.NodeReader;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class HostReaderClass implements HostReader{
String name;
int available_memory,available_storage,maxVNFs;
Set<NodeReader> node;

	@Override
	public String getName() {
		return name;
	}

	@Override
	public int getAvailableMemory() {
		return available_memory;
	}

	@Override
	public int getAvailableStorage() {
		return available_storage;
	}

	@Override
	public int getMaxVNFs() {
		return maxVNFs;
	}

	@Override
	public Set<NodeReader> getNodes() {
		return node;
	}

	public void setName(String name) {
		this.name = name;
	}


	public void setAvailable_memory(int available_memory) {
		this.available_memory = available_memory;
	}


	public void setAvailable_storage(int available_storage) {
		this.available_storage = available_storage;
	}

	public void setMaxVNFs(int maxVNFs) {
		this.maxVNFs = maxVNFs;
	}

	public Set<NodeReader> getNode() {
		return node;
	}

	public void setNode(Set<NodeReader> node) {
		this.node = node;
	}
}
