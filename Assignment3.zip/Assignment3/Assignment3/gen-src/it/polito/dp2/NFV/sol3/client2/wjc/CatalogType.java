
package it.polito.dp2.NFV.sol3.client2.wjc;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CatalogType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CatalogType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FW"/>
 *     &lt;enumeration value="DPI"/>
 *     &lt;enumeration value="NAT"/>
 *     &lt;enumeration value="SPAM"/>
 *     &lt;enumeration value="WEB_CLIENT"/>
 *     &lt;enumeration value="WEB_SERVER"/>
 *     &lt;enumeration value="MAIL_CLIENT"/>
 *     &lt;enumeration value="MAIL_SERVER"/>
 *     &lt;enumeration value="CACHE"/>
 *     &lt;enumeration value="VPN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CatalogType")
@XmlEnum
public enum CatalogType {

    FW,
    DPI,
    NAT,
    SPAM,
    WEB_CLIENT,
    WEB_SERVER,
    MAIL_CLIENT,
    MAIL_SERVER,
    CACHE,
    VPN;

    public String value() {
        return name();
    }

    public static CatalogType fromValue(String v) {
        return valueOf(v);
    }

}
