/**
 *
 */
package it.polito.dp2.NFV.sol1;

import static javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;

import javax.xml.bind.*;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.sol1.jaxb.*;
import org.xml.sax.SAXException;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class NfvReaderClass implements NfvReader {
	private ConnectionPerformanceReader cprs;
	private Set<ConnectionPerformanceReaderClass> cprsset;
	private Set<NffgReader> nffgs;
	private Set<HostReader> hosts;
	private HostReader host;
	private Set<VNFTypeReader> vnfcatalog;


	/**
	 * Getters and Setters
	 */

	@Override
	public ConnectionPerformanceReader getConnectionPerformance(HostReader arg0, HostReader arg1) {
		for(ConnectionPerformanceReaderClass c: cprsset) {

			if (c.getSrc().equalsIgnoreCase(arg0.getName()) && c.getDst().equalsIgnoreCase(arg1.getName()))
				//System.out.println("dest" +c.getDst());
				//System.out.println("src"+c.getSrc());
				return c;
		}
		return null;
	}

	@Override
	public HostReader getHost(String arg0) {
		for (HostReader hostReader : hosts) {
			if (hostReader.getName().equalsIgnoreCase(arg0))
				return hostReader;
		}
		return host;
	}

	@Override
	public Set<HostReader> getHosts() {
		return hosts;
	}

	@Override
	public NffgReader getNffg(String arg0) {
		for (NffgReader r : getNffgs(Calendar.getInstance()))
			if (r.getName().equalsIgnoreCase(arg0)) return r;
		return null;
	}

	@Override
	public Set<NffgReader> getNffgs(Calendar arg0) {
		if (nffgs == null)
			nffgs = new HashSet<>();
		return nffgs;
	}

	@Override
	public Set<VNFTypeReader> getVNFCatalog() {
		if (vnfcatalog == null)
			vnfcatalog = new HashSet<>();
		return vnfcatalog;
	}


	public NfvReaderClass() {
		nffgs = new HashSet<>();
		hosts = new HashSet<>();
		vnfcatalog = new HashSet<>();
		cprsset = new HashSet<>();

		JAXBContext jc;
		File f;
		Network network = null;
		try {
			/**
			 * Instantiate the JAXBContext,the Unmarshaller the Schema factory and set the event Handler
			 */
			jc = JAXBContext.newInstance("it.polito.dp2.NFV.sol1.jaxb");
			Unmarshaller u = jc.createUnmarshaller();
			SchemaFactory sf = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);
			try {
				Schema schema = sf.newSchema(new File("xsd/nfvInfo.xsd"));
				u.setSchema(schema);
				u.setEventHandler(
						ve -> {
							if (ve.getSeverity() != ValidationEvent.WARNING) {
								ValidationEventLocator vel = ve.getLocator();
								System.out.println("Line:Col[" + vel.getLineNumber() +
										":" + vel.getColumnNumber() +
										"]:" + ve.getMessage());
							}
							return true;
						}
				);
			} catch (SAXException se) {
				System.out.println("Unable to validate due to following error.");
				se.printStackTrace();
			}
			//Retrieve the filename from system property and pass it to the unmarshaller
			//then retrieve the network
			String property = System.getProperty("it.polito.dp2.NFV.sol1.NfvInfo.file");
			f = new File(property);
			JAXBElement<?> element = (JAXBElement<?>) u.unmarshal(f);
			network = (Network) element.getValue();

		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (ClassCastException cce) {
			cce.printStackTrace();
		} catch (NullPointerException c) {
			c.printStackTrace();
		}


		System.out.println("WORKING ON NFFG");
		ArrayList<NFFG> NFFGs = null;
		if (network != null) {
			NFFGs = (ArrayList<NFFG>) network.getNFFGs().getNFFG();
		}
		if (NFFGs != null) {
			for (NFFG o : NFFGs) {
				Set<NodeReader> nodes = new HashSet<NodeReader>();
				for (Node n : o.getNode()) {
					VNFReaderClass vnfs = new VNFReaderClass();
					vnfs.setName(n.getVNF().getName());
					vnfs.setRequiredMemory(n.getVNF().getMemoryAmount());
					vnfs.setRequiredStorage(n.getVNF().getDiskStorage());
					vnfs.setFunctional_type(FunctionalType.fromValue(n.getVNF().getType().name()));
					Set<LinkReader> links = new HashSet<LinkReader>();
					for (Link l : n.getLink()) {
						LinkReaderClass linkr = new LinkReaderClass();
						linkr.setName(l.getName());
						NodeReaderClass nodsrc = new NodeReaderClass();
						nodsrc.setName(l.getSrc());
						nodsrc.setFunction_type(vnfs);
						nodsrc.setLink(links);
						linkr.setSrcNode(nodsrc);
						NodeReaderClass nodedst = new NodeReaderClass();
						nodedst.setName(l.getDst());
						nodedst.setLink(links);
						nodedst.setFunction_type(vnfs);
						linkr.setDstNode(nodedst);
						links.add(linkr);
					}

					NodeReaderClass node = new NodeReaderClass();
					node.setName(n.getName());
					node.setFunction_type(vnfs);
					HostReaderClass hr = new HostReaderClass();
					hr.setName(n.getHostName());
					node.setHost(hr);
					node.setLink(links);
					nodes.add(node);

				}
				NffgReaderClass nffgr = new NffgReaderClass();
				nffgr.setName((o.getName()));
				nffgr.setNodes(nodes);
				nffgr.setUpdateTime(NfvInfoSerializer.toCalendar((o.getDeployTime())));
				nffgs.add(nffgr);

			}

		}





		System.out.println("WORKING ON HOST");
		ArrayList<Host> Hosts = null;
		if (network != null) {
			Hosts = (ArrayList<Host>) network.getHosts().getHost();
		}
		if (Hosts != null) {
			//iterate host
			for (Host h : Hosts) {
				Set<NodeReader> nodes = new HashSet<>();
				//iterate node
				for (Node n : h.getNode()) {
					VNFReaderClass vnfs = new VNFReaderClass();
					//Set all params for the vnf and for the node
					vnfs.setName(n.getVNF().getName());
					vnfs.setFunctional_type(FunctionalType.fromValue(n.getVNF().getType().name()));
					vnfs.setRequiredStorage(n.getVNF().getDiskStorage());
					vnfs.setRequiredMemory(n.getVNF().getMemoryAmount());
					NodeReaderClass node = new NodeReaderClass();
					node.setName(n.getName());
					node.setFunction_type(vnfs);
					//create a new host and add it to the node
					HostReaderClass hostr = new HostReaderClass();
					hostr.setName(h.getName());
					node.setHost(hostr);
					//iterate again the nffg in order to get the links in a correct way
					for (NFFG nffg : NFFGs) {
						for (Node n1 : nffg.getNode()) {
							if (n1.getName().equalsIgnoreCase(n.getName())) {
								Set<LinkReader> links = new HashSet<LinkReader>();
								for (Link l : n1.getLink()) {
									LinkReaderClass linkr = new LinkReaderClass();
									linkr.setName(l.getName());
									NodeReaderClass nodesrc = new NodeReaderClass();
									nodesrc.setName(l.getSrc());
									nodesrc.setFunction_type(vnfs);
									nodesrc.setLink(links);
									linkr.setSrcNode(nodesrc);
									NodeReaderClass nodedst = new NodeReaderClass();
									nodedst.setName(l.getDst());
									nodedst.setLink(links);
									nodedst.setFunction_type(vnfs);
									linkr.setDstNode(nodedst);
									//links.add(linkr);
									node.getLinks().add(linkr);
								}
							}
						}
					}
					nodes.add(node);
				}
				HostReaderClass hostr = new HostReaderClass();
				hostr.setName(h.getName());
				hostr.setNode(nodes);
				hostr.setMaxVNFs(h.getMaxNumberVFN());
				hostr.setAvailable_memory(h.getMemoryAmount());
				hostr.setAvailable_storage(h.getDiskStorage());
				hosts.add(hostr);
			}
		}



		System.out.println("WORKING ON CONNECTIONS");

		ArrayList<Connection> Connections = null;
		if (network != null) {
			Connections = (ArrayList<Connection>) network.getConnections().getConnection();
		}
		if (Connections != null) {
			for(Connection c: Connections){
				ConnectionPerformanceReaderClass cprc = new ConnectionPerformanceReaderClass();
				System.out.println("src:"+c.getSrc()+ " dst:"+c.getDst()+" lat:"+c.getLatency()+" thp:"+c.getAverageThroughput());
				cprc.setSrc(c.getSrc());
				cprc.setDst(c.getDst());
				cprc.setLatency(c.getLatency());
				cprc.setThroughput(c.getAverageThroughput());
				cprsset.add(cprc);
			}
		}
	}
}



