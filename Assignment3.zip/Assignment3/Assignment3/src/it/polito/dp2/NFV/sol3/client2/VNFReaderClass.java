/**
 * 
 */
package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.FunctionalType;
import it.polito.dp2.NFV.VNFTypeReader;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class VNFReaderClass implements VNFTypeReader {
String name;
FunctionalType functional_type;
int requiredMemory,requiredStorage;

/*
 * Getters and Setters
 */
	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public FunctionalType getFunctionalType() {
		return this.functional_type;
	}

	@Override
	public int getRequiredMemory() {
		return this.requiredMemory;
	}

	@Override
	public int getRequiredStorage() {
		return this.requiredStorage;
	}
	


public void setFunctional_type(FunctionalType functional_type) {
	this.functional_type = functional_type;
}

public void setName(String name) {
	this.name = name;
}

public void setRequiredMemory(int requiredMemory) {
	this.requiredMemory = requiredMemory;
}

public void setRequiredStorage(int requiredStorage) {
	this.requiredStorage = requiredStorage;
}



}
