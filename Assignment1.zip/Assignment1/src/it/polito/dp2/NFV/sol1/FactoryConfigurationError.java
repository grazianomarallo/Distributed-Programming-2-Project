/**
 * 
 */
package it.polito.dp2.NFV.sol1;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class FactoryConfigurationError  {
	String message, exception;
	
	public String getMessage() {
		return message;
	}
	
	public String getException() {
		return exception;
	}
	

}
