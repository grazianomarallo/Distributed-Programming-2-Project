package it.polito.dp2.NFV.sol3.service;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.sol3.service.xjc.*;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:24/02/2018
 */

public class Reader {
    private static NfvReader monitor;
    private static NeoService neoService;
    private ConcurrentMap<String, NFFG> loadedNffgs; //(NFFG name, NFFG object)
    private ConcurrentMap<String, Node> loadedNodes; // (Node name, Node object)
    private ConcurrentMap<String, Link> loadedLinks; // (NodeA_NodeB, Link object)
    private ConcurrentMap<String, Connection> loadedConnections; // (HostA-HostB, Connection object)
    private ConcurrentMap<String, VNF> loadedVNFs; // (VNFname, VNF object)
    private ConcurrentMap<String, List<String>> incomingLinks; //(Node name, Linkname)
    private ConcurrentMap<String, List<String>> outgoingLinks; //(Node name, Linkname)
    private AtomicInteger incrementNffg;
    private AtomicInteger incrementNode;


    /**
     * Getter for retrieve maps from NfvDeployer class
     */

    public ConcurrentMap<String, NFFG> getLoadedNffgs() {
        return loadedNffgs;
    }
    public ConcurrentMap<String, Node> getLoadedNodes() {
        return loadedNodes;
    }
    public ConcurrentMap<String, Link> getLoadedLinks() {
        return loadedLinks;
    }
    public ConcurrentMap<String, Connection> getLoadedConnections() {
        return loadedConnections;
    }
    public ConcurrentMap<String, VNF> getLoadedVNFs() {
        return loadedVNFs;
    }
    public ConcurrentMap<String, List<String>> getIncomingLinks() {
        return incomingLinks;
    }
    public ConcurrentMap<String, List<String>> getOutgoingLinks() {
        return outgoingLinks;
    }
    public AtomicInteger getIncrementNffg() {
        return incrementNffg;
    }
    public AtomicInteger getIncrementNode() {
        return incrementNode;
    }
    public  NeoService getNeoService() {
        return neoService;
    }

    /**
     * The Constructor get the instance of the monitor from the deployer
     * instantiate a new NeoService in order to load data on neo4js and
     * initialize all the maps that are needed to store data to handle service request

     */
    public Reader(){
        monitor = NfvDeployer.getMonitor();
        neoService = new NeoService();
        loadedNodes = new ConcurrentHashMap<>();
        loadedVNFs = new ConcurrentHashMap<>();
        loadedNffgs = new ConcurrentHashMap<>();
        loadedLinks = new ConcurrentHashMap<>();
        loadedConnections = new ConcurrentHashMap<>();
        incrementNffg = new AtomicInteger(0);
        incrementNode = new AtomicInteger(0);
        incomingLinks = new ConcurrentHashMap<>();
        outgoingLinks = new ConcurrentHashMap<>();
    }

    /**
     * Read data from the monitor and fill the VNF Object with the corresponding data.
     * The VNFs read from the monitor are stored  inside a map
     */
    public void loadVNFs() {
        //retrieve the VnfsCatalog from monitor
        Set<VNFTypeReader> vnfTypeReaders = monitor.getVNFCatalog();

        for (VNFTypeReader typeReader : vnfTypeReaders) {
            //create a new VNF obj and fill it with data            
            VNF vnf = new VNF();
            vnf.setMemoryAmount(BigInteger.valueOf(typeReader.getRequiredMemory()));
            vnf.setName(typeReader.getName());
            vnf.setDiskStorage(BigInteger.valueOf(typeReader.getRequiredStorage()));
            vnf.setType(CatalogType.fromValue(typeReader.getFunctionalType().value()));
            //store data inside the map
            loadedVNFs.put(vnf.getName(), vnf);
        }

       
    }

    /**
     * Read data from the monitor and fill the Host Object with the corresponding data.
     * The Hosts read from the monitor are stored  inside a map
     */
    public void loadHosts(){
        Set<HostReader> hostReaders = monitor.getHosts();
        for (HostReader hostReader : hostReaders) {
            //create a new Host obj and fill it with data
            Host host = new Host();
            host.setName(hostReader.getName());
            host.setMaxNumberVFN(BigInteger.valueOf(hostReader.getMaxVNFs()));
            host.setDiskStorage(BigInteger.valueOf(hostReader.getAvailableStorage()));
            host.setMemoryAmount(BigInteger.valueOf(hostReader.getAvailableMemory()));
            //store the host loaded inside the LoadedHostmap and inside the map
            //that keep track of the node allocated on the host
            neoService.getAllocatedNodes().put(host.getName(), new CopyOnWriteArrayList<String>());
            neoService.getLoadedHosts().put(host.getName(), host);
        }

    }

    /**
     * Read data from the monitor and fill the Connection Object with the corresponding data.
     * The Connections read from the monitor are stored  inside a map
     */
    public void loadConnections() {
        Set<HostReader> hostReader = monitor.getHosts();
        // Read from the nested loop the connection relative to the source Host and destination Host
        for (HostReader hri : hostReader) {
            for (HostReader hrj : hostReader) {
                ConnectionPerformanceReader cpr = monitor.getConnectionPerformance(hri, hrj);
                //create a new Connection  obj and fill it with data
                Connection connection = new Connection();
                connection.setSrc(hri.getName());
                connection.setDst(hrj.getName());
                connection.setAvarageLatency(BigInteger.valueOf(cpr.getLatency()));
                connection.setAverageThroughput(cpr.getThroughput());
                //store data inside the map the name of the source and dest separate by a "-" char
                loadedConnections.put(connection.getSrc() + "-" + connection.getDst(),connection);
            }
        }
    }

    /**
     * Read data from the monitor and fill the NFFG Object with the corresponding data.
     * The Nffg read from the monitor are stored in inside a map
     */
    public void loadNffg() throws DatatypeConfigurationException {
        //retrieve the nffg0 from monitor
        String nffg_name= "Nffg0";
        NffgReader nffgReader = monitor.getNffg(nffg_name);
        if (nffgReader == null) {
            return;
        }
        //create a new NFFG object and fill with data
        NFFG nffg = new NFFG();
        nffg.setName(nffgReader.getName());

        //create a new Nodes Object
        Nodes nodes = new Nodes();
        for (NodeReader nodeReader : nffgReader.getNodes()) {
            Node node = new Node();
            node.setName(nodeReader.getName());
            node.setNameNffg(nodeReader.getNffg().getName());
            node.setNameVnf(nodeReader.getFuncType().getName());
            node.setAllocatedOn(nodeReader.getHost().getName());

            //try to load the  nffg's node on Neo4j service
            try {
                neoService.loadNeoNode(node);
            } catch (ServiceException S) {
                S.printStackTrace();
            }
            nodes.getNode().add(node);
            //Store node inside map
            incomingLinks.put(nodeReader.getName(), new CopyOnWriteArrayList<String>());
            outgoingLinks.put(nodeReader.getName(), new CopyOnWriteArrayList<String>());
            loadedNodes.put(node.getName(), node);
            incrementNode.incrementAndGet();
        }

        nffg.setDeployTime(getXMLGregorianCalendarNow());
        nffg.setNodes(nodes);
        loadedNffgs.put(nffgReader.getName(), nffg);
        loadLinks();
        incrementNffg.incrementAndGet();
    }

    /**
     * Read data from the monitor and fill the Links Object relative to nffg0 with the corresponding data.
     * The Links read from the monitor are stored in inside a map
     */
    private void loadLinks() {
        String nffg_name= "Nffg0";
        NffgReader nffgReader = monitor.getNffg(nffg_name);
        if (nffgReader == null) {
            return;
        }
        Links links = new Links();
        for (NodeReader nodeReader : nffgReader.getNodes()) {
            for (LinkReader linkReader : nodeReader.getLinks()) {
                Link link = new Link();
                link.setName(nodeReader.getName() + "_" + linkReader.getDestinationNode().getName());
                link.setSrc(linkReader.getSourceNode().getName());
                link.setDst(linkReader.getDestinationNode().getName());
                link.setMaxLatency(BigInteger.valueOf(linkReader.getLatency()));
                link.setMinThroughput(linkReader.getThroughput());

                loadedLinks.put(nodeReader.getName() + "_" + linkReader.getDestinationNode().getName(), link);

                links.getLink().add(link);

                // try to load link on Neo4J service
                try {
                    neoService.loadNeoLink(link);
                } catch (ServiceException S) {
                    S.printStackTrace();
                }

                outgoingLinks.get(linkReader.getSourceNode().getName()).add(link.getName());
                incomingLinks.get(linkReader.getDestinationNode().getName()).add(link.getName());

            }
        }
        loadedNffgs.get(nffgReader.getName()).setLinks(links);
    }





    private XMLGregorianCalendar getXMLGregorianCalendarNow()
            throws DatatypeConfigurationException {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();
        return datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
    }

}
