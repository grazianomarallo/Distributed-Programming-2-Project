package it.polito.dp2.NFV.sol3.service;

import it.polito.dp2.NFV.sol3.service.wjc.*;
import it.polito.dp2.NFV.sol3.service.xjc.Host;
import it.polito.dp2.NFV.sol3.service.xjc.Link;

import javax.inject.Singleton;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:24/02/2018
 */
public class NeoService {
    private Client client;
    public WebTarget target;
    private static Reader reader;
    private ConcurrentMap<String, String> neoHostMap; // (Host name, ID)
    private ConcurrentMap<String, String> neoNodeMap; // (Node name, ID)
    public ConcurrentMap<String, Host> loadedHosts; //  (Host name, Host Object)
    private ConcurrentMap<String, List<String>> allocatedNodes; // (HostName, <id,id>)

    /**
     * Get method to retrieve map from NfvDeployer
     * @return
     */
    public ConcurrentMap<String, String> getNeoHostMap() {
        return neoHostMap;
    }
    public ConcurrentMap<String, String> getNeoNodeMap() {
        return neoNodeMap;
    }
    public ConcurrentMap<String, Host> getLoadedHosts() {
        return loadedHosts;
    }
    public ConcurrentMap<String, List<String>> getAllocatedNodes() {
        return allocatedNodes;
    }



    public NeoService()  {
        client = ClientBuilder.newClient();
        target = client.target(getBaseURI());
        reader= NfvDeployer.getReader();
        neoHostMap = new ConcurrentHashMap<>();
        neoNodeMap = new ConcurrentHashMap<>();
        loadedHosts = new ConcurrentHashMap<>();
        allocatedNodes = new ConcurrentHashMap<>();
    }


    /**
     * This method allows to load a node on Neo4J service
     * @param node that has to be loaded
     * @throws ServiceException in case one of the three error code are received into the response
     */
    public void loadNeoNode(it.polito.dp2.NFV.sol3.service.xjc.Node node) throws ServiceException {
        Node neoNode = new Node();

        Property property = new Property();
        property.setName("name");
        property.setValue(node.getName());

        Properties properties = new Properties();
        properties.getProperty().add(property);
        neoNode.setProperties(properties);

        Response nodeResponse = target.path("/data/node/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(neoNode, MediaType.APPLICATION_XML));

        checkResponse(nodeResponse);

        //save the id of the posted node
        String id = nodeResponse.readEntity(Node.class).getId();

        //store inside a map the node name and the correspondant id
        neoNodeMap.put(node.getName(), id);

        Labels labels = new Labels();
        labels.getLabel().add("Node");

        Response labelResponse = target.path("/data/node/" + id + "/labels")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(labels, MediaType.APPLICATION_XML));

        checkResponse(labelResponse);

        //check if the host on which the current node is allocated exists in the map
        //if not get the host and load it on neo4j service
         if (!neoHostMap.containsKey(node.getAllocatedOn())) {
            loadNeoHost(loadedHosts.get(node.getAllocatedOn()));
         }

        Relationship relationship = new Relationship();
        relationship.setType("AllocatedOn");
        relationship.setDstNode(neoHostMap.get(node.getAllocatedOn()));
        relationship.setSrcNode(id);

        Response relationshipResponse = target.path("/data/node/" + id + "/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship, MediaType.APPLICATION_XML));

        checkResponse(relationshipResponse);

    }

    /**
     * This method allows to load inside Neo4J service an host
     * @param host that has to be loaded
     * @throws ServiceException in case one of the three error code are received into the response
     */
    public void loadNeoHost(Host host) throws ServiceException {
        Node node = new Node();

        Property property = new Property();
        property.setName("name");
        property.setValue(host.getName());

        Properties properties = new Properties();
        properties.getProperty().add(property);

        node.setProperties(properties);

        Response hostResponse = target.path("/data/node/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(node, MediaType.APPLICATION_XML));

        checkResponse(hostResponse);

        String id = hostResponse.readEntity(Node.class).getId();

        //save inside the host map host name and relative id
        neoHostMap.put(host.getName(), id);
        //save inside the map the hostname in order to keep track of the node allocated
        allocatedNodes.put(host.getName(), new ArrayList<>());

        Labels labels = new Labels();
        labels.getLabel().add("Host");

        Response res = target.path("/data/node/" + id + "/labels")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(labels, MediaType.APPLICATION_XML));

        checkResponse(res);
    }

    /**
     * This method allows to load a link inside the Neo4j service
     * @param link that has to be loaded
     * @throws ServiceException
     */
    public void loadNeoLink(Link link) throws ServiceException {
        Relationship relationship = new Relationship();
        relationship.setType("ForwardsTo");
        relationship.setSrcNode(neoNodeMap.get(link.getSrc()));
        relationship.setDstNode(neoNodeMap.get(link.getDst()));


        Response linkResponse = target.path("/data/node/" +
                neoNodeMap.get(link.getSrc()) + "/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship, MediaType.APPLICATION_XML));
        checkResponse(linkResponse);
    }

    private static URI getBaseURI() {
        return UriBuilder.fromUri(System.getProperty(
                "it.polito.dp2.NFV.lab3.Neo4JSimpleXMLURL",
                "http://localhost:8080/Neo4JSimpleXML/rest")).build();
    }


    @SuppressWarnings("Duplicates")
    public void checkResponse (Response response) throws ServiceException {
        switch (response.getStatus()) {
            case 400:
                throw new ServiceException("ServiceException: Bad Request on Neo4J");
            case 404:
                throw new ServiceException("ServiceException: Not Found on Neo4J");
            case 500:
                throw new ServiceException("ServiceException: Internal Server Error on Neo4J");
            default:
                break;
        }
    }
}