/**
 * 
 */
package it.polito.dp2.NFV.sol1;

import java.util.Calendar;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import it.polito.dp2.NFV.NffgReader;
import it.polito.dp2.NFV.NodeReader;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class NffgReaderClass implements NffgReader{
String name;
NodeReader node;
Set<NodeReader> nodes ;
Calendar deployTime;

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Calendar getDeployTime() {
		return deployTime;
	}

	@Override
	public NodeReader getNode(String arg0) {
		for(NodeReader n: nodes)
			if(n.getName().equalsIgnoreCase(arg0)) return n;
		return null;

	}

	@Override
	public Set<NodeReader> getNodes() {
		return nodes;
	}

	public NodeReader getNode() {
		return node;
	}

	public void setNode(NodeReader node) {
		this.node = node;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setNodes(Set<NodeReader> nodes) {
		this.nodes = nodes;
	}

	public static Calendar toCalendar(XMLGregorianCalendar calendar){
		return calendar.toGregorianCalendar();
	}

	public void setUpdateTime(Calendar deployTime) {
		this.deployTime = deployTime;
		
	}
	
	

}
