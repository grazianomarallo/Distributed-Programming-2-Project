/**
 * 
 */
package it.polito.dp2.NFV.sol1;

import java.util.HashSet;
import java.util.Set;

import it.polito.dp2.NFV.*;

/**
 * @author Graziano Marallo
 *
 */
public class NodeReaderClass implements NodeReader {
String name;	
VNFTypeReader function_type;
HostReader host;
NffgReader nffg;
Set<LinkReader> links = new HashSet<>();

	/**
	 * Getter and Setters
	 */


	@Override
	public VNFTypeReader getFuncType() {
		return function_type;
	}
	@Override
	public Set<LinkReader> getLinks() {
		return links;
	}

	@Override
	public HostReader getHost() {
		return host;
	}

	@Override
	public NffgReader getNffg() {
		return nffg;
	}

	@Override
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public void setFunction_type(VNFTypeReader function_type) {
		this.function_type = function_type;
	}

	public void setHost(HostReader host) {
		this.host = host;
	}

	public void setNffg(NffgReader nffg) {
		this.nffg = nffg;
	}

	public void setLink(Set<LinkReader> links) {
		this.links = links;
	}
}
