/*
package it.polito.dp2.NFV.sol3.service;


import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.sol3.service.wjc.Labels;
import it.polito.dp2.NFV.sol3.service.wjc.Properties;
import it.polito.dp2.NFV.sol3.service.wjc.Property;
import it.polito.dp2.NFV.sol3.service.wjc.Relationship;
import it.polito.dp2.NFV.sol3.service.xjc.*;
import org.apache.commons.lang.NotImplementedException;


import javax.inject.Singleton;
import javax.ws.rs.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.xml.bind.*;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.math.BigInteger;
import java.net.URI;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import static javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI;



@Singleton
@Path("/")
public class Deployer  {

    private static NfvReader monitor;
    private Client client;
    public WebTarget target;


    private final ReentrantReadWriteLock lockRW;
    private final Lock lockR;
    private final Lock lockW;

    private ConcurrentMap<String, NFFG> loadedNffgs; // Nffg0, XML
    private ConcurrentMap<String, Node> loadedNodes; // Node0, XML
    private ConcurrentMap<String, Link> loadedLinks; // Node0_Node1, XML
    private ConcurrentMap<String, Host> loadedHosts; //Host0, XML
    private ConcurrentMap<String, Connection> loadedConnections; // Host1_Host0, XML
    private ConcurrentMap<String, VNF> loadedVNFs; //MailClient_a, XML
    public ConcurrentMap<String, String> neoHostMap; // Host0, 132  (Host name, ID)
    public ConcurrentMap<String, String> neoNodeMap; // Node0, 15  (Node name, ID)



    private ConcurrentMap<String, List<String>> allocatedNodes; // Host0, <134, 12> //nodes allocated on hosts

    private ConcurrentMap<String, List<String>> incomingLinks;
    private ConcurrentMap<String, List<String>> outgoingLinks;

    private AtomicInteger incrementNffg;
    private AtomicInteger incrementNode;


    public Deployer() throws DatatypeConfigurationException {

        NfvReaderFactory factory = NfvReaderFactory.newInstance();
        try {
            monitor = factory.newNfvReader();
        } catch (NfvReaderException e) {
            System.err.println("ERROR: Cannot instanciate NfvReaderFactory in NfvDeployer");
            e.printStackTrace();
        }
        client = ClientBuilder.newClient();
        target = client.target(getBaseURI());

        //Initialize lock for read and write operation and ensure atomic operation
        lockRW = new ReentrantReadWriteLock();
        lockR = lockRW.readLock();
        lockW = lockRW.writeLock();


        //retrieve all the maps already filled by the Reader
        loadedHosts = new ConcurrentHashMap<>();
        loadedNodes = new ConcurrentHashMap<>();
        loadedVNFs = new ConcurrentHashMap<>();
        loadedNffgs = new ConcurrentHashMap<>();
        loadedLinks = new ConcurrentHashMap<>();
        loadedConnections = new ConcurrentHashMap<>();
        allocatedNodes = new ConcurrentHashMap<>();
        incrementNffg = new AtomicInteger(0);
        incrementNode = new AtomicInteger(0);

        incomingLinks = new ConcurrentHashMap<>();
        outgoingLinks = new ConcurrentHashMap<>();



        neoHostMap = new ConcurrentHashMap<>();
        neoNodeMap = new ConcurrentHashMap<>();

        //Load the Nffg0 and all the informations needed
        loadIN();
        loadNffg(monitor.getNffg("Nffg0"));
        loadConnections();



    }

    //This method allow the Marshall of the object passed as parameter
    private void performMarshall(Class c, Object obj ){


        try {
            // create jaxb context
            JAXBContext jaxbContext = JAXBContext.newInstance(c);

            SchemaFactory sf = SchemaFactory.newInstance(W3C_XML_SCHEMA_NS_URI);
            Schema schema = sf.newSchema(Deployer.class.getResource("/xsd/NfvDeployer.xsd"));

            // create Marshaller using JAXB context
            Marshaller m = jaxbContext.createMarshaller();
            m.setSchema(schema);
            m.marshal(obj, System.out);

        } catch (JAXBException e) {
            throw new BadRequestException();
        } catch (org.xml.sax.SAXException e) {
            throw new BadRequestException();
        }


    }


    @GET
    @Path("nffgs")
    @Produces(MediaType.APPLICATION_XML)
    public NFFGs getNFFGs() {
        NFFGs nffgs = new NFFGs();
        lockR.lock();
        try {
            for (NFFG nffg : loadedNffgs.values()) {
                nffgs.getNFFG().add(nffg);
            }
        } finally {
            lockR.unlock();
        }
        return nffgs;
    }

    @POST
    @Path("nffgs")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public NFFG postNFFG(NFFG nffg) throws DatatypeConfigurationException {
        performMarshall(NFFG.class,nffg);
        nffg.setName("Nffg" + incrementNffg.toString());
        Integer allocated = 0;
        Nodes nodes = new Nodes();
        lockW.lock();
        try {

            if (nffg.getNodes() != null) {

                for (Node node : nffg.getNodes().getNode()) {

                    node.setNameNffg(nffg.getName());
                    node.setName("Node" + incrementNode.toString());

                    if (node.getAllocatedOn() == null) {
                        try {
                            if (!seekHost_AllocNode(node)) {

                                for (Node node1 : nffg.getNodes().getNode()) {
                                    if (allocated == 0) break;

                                    removeNodeFromHost(node1.getAllocatedOn(), node1);
                                    allocatedNodes.get(node.getAllocatedOn()).remove(node.getName());
                                    incomingLinks.remove(node.getName());
                                    outgoingLinks.remove(node.getName());
                                    allocated--;
                                }

                                throw new ForbiddenException();
                            }
                        } catch (ServiceException S) {
                            for (Node node2 : nffg.getNodes().getNode()) {
                                if (allocated == 0) break;

                                removeNodeFromHost(node2.getAllocatedOn(), node2);
                                allocatedNodes.get(node.getAllocatedOn()).remove(node.getName());
                                incomingLinks.remove(node.getName());
                                outgoingLinks.remove(node.getName());
                                allocated--;
                            }

                            throw new InternalServerErrorException();
                        }
                    } else {
                        if (!loadedHosts.containsKey(node.getAllocatedOn())) throw new NotFoundException();
                        try {
                            if (!canAllocate(node.getAllocatedOn(), node)) {
                                if (!seekHost_AllocNode(node)) {
                                    for (Node node3 : nffg.getNodes().getNode()) {
                                        if (allocated == 0) break;

                                        removeNodeFromHost(node3.getAllocatedOn(), node3);

                                        incomingLinks.remove(node.getName());
                                        outgoingLinks.remove(node.getName());
                                        allocated--;
                                    }

                                    throw new ForbiddenException();
                                }
                            }
                        } catch (ServiceException S) {
                            for (Node node4 : nffg.getNodes().getNode()) {
                                if (allocated == 0) break;

                                removeNodeFromHost(node4.getAllocatedOn(), node4);
                                allocatedNodes.get(node.getAllocatedOn()).remove(node.getName());
                                incomingLinks.remove(node.getName());
                                outgoingLinks.remove(node.getName());
                                allocated--;
                            }

                            throw new InternalServerErrorException();
                        }
                    }

                    allocated++;
                    incrementNode.incrementAndGet();
                    incomingLinks.put(node.getName(), new CopyOnWriteArrayList<>());
                    outgoingLinks.put(node.getName(), new CopyOnWriteArrayList<>());
                    loadedNodes.put(node.getName(), node);
                    nodes.getNode().add(node);
                }
            }

            nffg.setDeployTime(getXMLGregorianCalendarNow());

            incrementNffg.incrementAndGet();

            loadedNffgs.put(nffg.getName(), nffg);

            Links links = new Links();

            loadedNffgs.get(nffg.getName()).setNodes(nodes);
            loadedNffgs.get(nffg.getName()).setLinks(links);

            return nffg;
        } finally {
            lockW.unlock();
        }
    }


    private boolean seekHost_AllocNode(Node node) throws ServiceException {
        for (String host : loadedHosts.keySet()) {
            if (canAllocate(host, node)) return true;
        }
        return false;
    }



    @GET
    @Path("nffgs/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public NFFG getNFFG(@PathParam("id") String id) {

        NFFG nffg;
        lockR.lock();
        try {
            if (!loadedNffgs.containsKey(id) || id == null || id.trim().length() == 0) {
                throw new NotFoundException();
            }
            nffg = loadedNffgs.get(id);
        } finally {
            lockR.unlock();
        }
        return nffg;

    }

    @DELETE
    @Path("nffgs/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public NFFG deleteNFFG(@PathParam("id") String id) {

        throw new NotImplementedException();

    }

    @GET
    @Path("nffgs/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    public Nodes getNodesOnNFFG(@PathParam("id") String id) {
        Nodes nodes;
        lockR.lock();
        try {
            if (!loadedNffgs.containsKey(id) || id == null || id.trim().length() == 0) {
                throw new NotFoundException();
            }
            nodes = loadedNffgs.get(id).getNodes();

        } finally {
            lockR.unlock();
        }
        return nodes;

    }


    @POST
    @Path("nffgs/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public Node postNodeOnNFFG(Node node, @PathParam("id") String id,
                               @DefaultValue("no")
                               @QueryParam("suggestedHost") String suggest) {
        performMarshall(Node.class,node);

        lockW.lock();

        try {

            if (!loadedNffgs.containsKey(id)) {
                throw new NotFoundException();
            }

            if (suggest.equals("yes") && node.getAllocatedOn() == null) {
                throw new BadRequestException();
            }

            if (suggest.equals("yes") && !loadedHosts.containsKey(node.getAllocatedOn())) {
                throw new NotFoundException();
            }

            node.setName("Node" + incrementNode.toString());
            node.setNameNffg(id);

            try {
                if (suggest.equals("no")) {
                    if (!seekHost_AllocNode(node)) {
                        throw new ForbiddenException();
                    }
                } else {
                    if (!canAllocate(node.getAllocatedOn(), node)) {
                        if (!seekHost_AllocNode(node)) {
                            throw new ForbiddenException();
                        }
                    }
                }
            } catch (ServiceException S) {
                throw new InternalServerErrorException();
            }

            loadedNffgs.get(id).getNodes().getNode().add(node);
            incomingLinks.put(node.getName(), new CopyOnWriteArrayList<>());
            outgoingLinks.put(node.getName(), new CopyOnWriteArrayList<>());
            incrementNode.incrementAndGet();

            return node;
        } finally {
            lockW.unlock();
        }

    }

    @GET
    @Path("nffgs/{id}/nodes/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Node getNodeOnNFFG(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }
            return loadedNodes.get(id2);
        } finally {
            lockR.unlock();
        }

    }

    @DELETE
    @Path("nffgs/{id}/nodes/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Node deleteNodeOnNFFG(@PathParam("id") String id, @PathParam("id2") String id2) {

        throw new NotImplementedException();

    }


    @GET
    @Path("nffgs/{id}/links")
    @Produces(MediaType.TEXT_XML)
    public Links getLinksOnNffg(@PathParam("id") String id) {

        Links links;
        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id)) {
                throw new NotFoundException();
            }
            links = loadedNffgs.get(id).getLinks();
        } finally {
            lockR.unlock();
        }

        return links;

    }

    @GET
    @Path("nffgs/{id}/links/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Link getLinkOnNffg(@PathParam("id") String id,  @PathParam("id2") String id2) {

        Link link;
        lockR.lock();


        try {
            if (!loadedNffgs.containsKey(id) || !loadedLinks.containsKey(id2)
                    || !loadedNodes.get(loadedLinks.get(id2).getSrc()).getNameNffg().equals(id)
                    || !loadedNodes.get(loadedLinks.get(id2).getDst()).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }
            link = loadedLinks.get(id2);
        } finally {
            lockR.unlock();
        }

        return link;

    }

    @DELETE
    @Path("nffgs/{id}/links/{id2}")
    @Produces(MediaType.APPLICATION_XML)
    public Link deleteLinkOnNffg(@PathParam("id") String id,
                                 @PathParam("id2") String id2) {
        throw new NotImplementedException();
    }

    @POST
    @Path("nffgs/{id}/links")
    @Produces(MediaType.APPLICATION_XML)
    @Consumes(MediaType.APPLICATION_XML)
    public Link postLinkOnNffg(@PathParam("id") String id, Link link,
                               @DefaultValue("false")
                               @QueryParam("overwrite") String overwrite) {
        performMarshall(Link.class,link);
        lockW.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(link.getSrc())
                    || !loadedNodes.containsKey(link.getDst())
                    || !loadedNodes.get(link.getSrc()).getNameNffg().equals(id)
                    || !loadedNodes.get(link.getDst()).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            if (overwrite.equals("false") && loadedLinks.containsKey(link.getSrc() + "_" + link.getDst())) {
                throw new ForbiddenException();
            }

            if (overwrite.equals("true")) {
                link.setName(link.getSrc() + "_" + link.getDst());
                loadedLinks.put(link.getName(), link);
                return link;
            }

            link.setName(link.getSrc() + "_" + link.getDst());
            if (link.getMinThroughput() == null) link.setMinThroughput(Float.valueOf(0));
            if (link.getMaxLatency() == null) link.setMaxLatency(BigInteger.valueOf(0));


            try {
             loadNeoLink(link);
            } catch (ServiceException S) {
                throw new InternalServerErrorException();
            }

            loadedLinks.put(link.getSrc() + "_" + link.getDst(), link);
            outgoingLinks.get(link.getSrc()).add(link.getName());
            incomingLinks.get(link.getDst()).add(link.getName());
            loadedNffgs.get(id).getLinks().getLink().add(link);

            return link;

        } finally {
            lockW.unlock();
        }

    }

    @GET
    @Path("nffgs/{id}/nodes/{id2}/reachableHosts")
    @Produces(MediaType.APPLICATION_XML)
    public Hosts getReachableHostFromNode(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Response res =target.path("/data/node/" +
                    neoNodeMap.get(id2) + "/reachableNodes")
                    .queryParam("relationshipTypes", "AllocatedOn|ForwardsTo")
                    .queryParam("nodeLabel","Host")
                    .request(MediaType.APPLICATION_XML)
                    .accept(MediaType.APPLICATION_XML)
                    .get();


            try {
                checkResponse(res);
            } catch (ServiceException e) {
                e.printStackTrace();
            }

            it.polito.dp2.NFV.sol3.service.wjc.Nodes myReachableNodes = res.readEntity(it.polito.dp2.NFV.sol3.service.wjc.Nodes.class);
            Hosts hosts = new Hosts();
            for (it.polito.dp2.NFV.sol3.service.wjc.Nodes.Node node : myReachableNodes.getNode()) {
                Host host;
                host = loadedHosts.get(node.getProperties().getProperty().get(0).getValue());

                hosts.getHost().add(host);
            }

            return hosts;
        } finally {
            lockR.unlock();
        }

    }

    @GET
    @Path("nffgs/{id}/nodes/{id2}/links/in")
    @Produces(MediaType.APPLICATION_XML)
    public Links getIncomingLinksOnNode(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Links links = new Links();

            for (String string : incomingLinks.get(id2)) {
                links.getLink().add(loadedLinks.get(string));
            }

            return links;
        } finally {
            lockR.unlock();
        }
    }

    @GET
    @Path("nffgs/{id}/nodes/{id2}/links/out")
    @Produces(MediaType.APPLICATION_XML)
    public Links getOutcomingLinksOnNode(@PathParam("id") String id, @PathParam("id2") String id2) {

        lockR.lock();

        try {
            if (!loadedNffgs.containsKey(id) || !loadedNodes.containsKey(id2) || !loadedNodes.get(id2).getNameNffg().equals(id)) {
                throw new NotFoundException();
            }

            Links links = new Links();

            for (String string : outgoingLinks.get(id2)) {
                links.getLink().add(loadedLinks.get(string));
            }

            return links;
        } finally {
            lockR.unlock();
        }

    }

    @GET
    @Path("hosts")
    @Produces(MediaType.APPLICATION_XML)
    public Hosts getHostsInXML() {
        lockR.lock();
        try {
            Hosts hosts = new Hosts();
            for (Host host : loadedHosts.values()) hosts.getHost().add(host);
            return hosts;
        } finally {
            lockR.unlock();
        }
    }

    @GET
    @Path("hosts/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Host getHostInXML(@PathParam("id") String id) {

        lockR.lock();

        try {
            if (!loadedHosts.containsKey(id)) throw new NotFoundException();

            return loadedHosts.get(id);
        } finally {
            lockR.unlock();
        }
    }

    @GET
    @Path("hosts/{id}/nodes")
    @Produces(MediaType.APPLICATION_XML)
    public Nodes getNodesAllocatedOnHostInXML(@PathParam("id") String id) {

        lockR.lock();

        try {
            if (!loadedHosts.containsKey(id)) throw new NotFoundException();

            Nodes nodes = new Nodes();
            for (String S : allocatedNodes.get(id)) nodes.getNode().add(loadedNodes.get(S));

            return nodes;
        } finally {
            lockR.unlock();
        }
    }

    @GET
    @Path("connections")
    @Produces(MediaType.APPLICATION_XML)
    public Connections getConnectionsInXML() {
        Connections connections = new Connections();
        for (Connection connection : loadedConnections.values()) connections.getConnection().add(connection);
        return connections;

    }

    @GET
    @Path("/connections/connection")
    @Produces(MediaType.APPLICATION_XML)
    public Connection getConnectionInXML(@DefaultValue("none") @QueryParam("src") String src, @DefaultValue("none") @QueryParam("dst") String dst) {

        if (src.equals("none") || dst.equals("none") || !loadedConnections.containsKey(src + "_" + dst)) {
            throw new NotFoundException();
        }
        return loadedConnections.get(src + "_" + dst);
    }

    @GET
    @Path("catalog")
    @Produces(MediaType.APPLICATION_XML)
    public VNFs getCatalogInXML() {
        VNFs VNFs = new VNFs();
        for (VNF V : loadedVNFs.values()) VNFs.getVNF().add(V);
        return VNFs;
    }

    @GET
    @Path("catalog/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public VNF getVNFFromCatalogInXML(@PathParam("id") String id) {
        if (!loadedVNFs.containsKey(id)) throw new NotFoundException();
        return loadedVNFs.get(id);

    }

    private boolean canAllocate(String host, Node node) throws ServiceException {
        BigInteger maxVnf = loadedHosts.get(host).getMaxNumberVFN();
        BigInteger hostMemory = loadedHosts.get(host).getMemoryAmount();
        BigInteger hostStorage =  loadedHosts.get(host).getDiskStorage();
        BigInteger vnfMemory = loadedVNFs.get(node.getNameVnf()).getMemoryAmount();
        BigInteger vnfStorage = loadedVNFs.get(node.getNameVnf()).getDiskStorage();

        if (maxVnf.intValue() >= 1 && hostMemory.intValue() >= vnfMemory.intValue() && hostStorage.intValue() >= vnfStorage.intValue()) {
            loadedHosts.get(host).setMaxNumberVFN(maxVnf.subtract(BigInteger.valueOf(1)));
            loadedHosts.get(host).setMemoryAmount(hostMemory.subtract(vnfMemory));
            loadedHosts.get(host).setDiskStorage(hostStorage.subtract(vnfStorage));
            node.setAllocatedOn(host);

            try {
                loadNeoNode(node);
            } catch (ServiceException S) {
                loadedHosts.get(host).setMaxNumberVFN(maxVnf.add(BigInteger.valueOf(1)));
                loadedHosts.get(host).setMemoryAmount(hostMemory.add(vnfMemory));
                loadedHosts.get(host).setDiskStorage(hostStorage.add(vnfStorage));
                throw new ServiceException();
            }
          loadNeoNode(node);
            loadedNodes.put(node.getName(), node);
            allocatedNodes.get(host).add(node.getName());
            return true;
        } else return false;
    }

    private void removeNodeFromHost(String host, Node node) {
        BigInteger maxVnf = loadedHosts.get(host).getMaxNumberVFN();
        BigInteger hostMemory = loadedHosts.get(host).getMemoryAmount();
        BigInteger hostStorage =  loadedHosts.get(host).getDiskStorage();
        BigInteger vnfMemory = loadedVNFs.get(node.getNameVnf()).getMemoryAmount();
        BigInteger vnfStorage = loadedVNFs.get(node.getNameVnf()).getDiskStorage();

        loadedHosts.get(host).setMaxNumberVFN(maxVnf.add(BigInteger.valueOf(1)));
        loadedHosts.get(host).setMemoryAmount(hostMemory.add(vnfMemory));
        loadedHosts.get(host).setDiskStorage(hostStorage.add(vnfStorage));

        try {
            Response response = target.path("/data/node/" +neoHostMap.get(node.getName()))
                    .request("application/xml")
                    .delete();

            try {
               checkResponse(response);
            } catch (ServiceException e) {
                e.printStackTrace();
            }

        } finally {
            allocatedNodes.get(host).remove(node.getName());

            loadedNodes.remove(node.getName());
           neoNodeMap.remove(node.getName());
        }
    }

    public void loadIN() {
        Set<VNFTypeReader> catalog = monitor.getVNFCatalog();

        for (VNFTypeReader typeReader : catalog) {
            VNF vnf = new VNF();
            vnf.setMemoryAmount(BigInteger.valueOf(typeReader.getRequiredMemory()));
            vnf.setName(typeReader.getName());
            vnf.setDiskStorage(BigInteger.valueOf(typeReader.getRequiredStorage()));
            vnf.setType(CatalogType.fromValue(typeReader.getFunctionalType().value()));

            loadedVNFs.put(vnf.getName(), vnf);
        }

        for (HostReader hostReader : monitor.getHosts()) {
            Host host = new Host();
            host.setName(hostReader.getName());
            host.setMaxNumberVFN(BigInteger.valueOf(hostReader.getMaxVNFs()));
            host.setDiskStorage(BigInteger.valueOf(hostReader.getAvailableStorage()));
            host.setMemoryAmount(BigInteger.valueOf(hostReader.getAvailableMemory()));

            allocatedNodes.put(host.getName(), new CopyOnWriteArrayList<>());

            loadedHosts.put(host.getName(), host);
        }
    }

    public void loadConnections() {
        Set<HostReader> hostReader = monitor.getHosts();

        for (HostReader hri : hostReader) {
            for (HostReader hrj : hostReader) {
                ConnectionPerformanceReader cpr = monitor.getConnectionPerformance(hri, hrj);
                Connection connection = new Connection();

                connection.setSrc(hri.getName());
                connection.setDst(hrj.getName());
                connection.setAvarageLatency(BigInteger.valueOf(cpr.getLatency()));
                connection.setAverageThroughput(cpr.getThroughput());

                loadedConnections.put(connection.getSrc() + "_" + connection.getDst(),connection);
            }
        }
    }

    public void loadNffg(NffgReader NFFG) throws DatatypeConfigurationException {
        if (NFFG == null) {
            return;
        }

        NFFG nffg = new NFFG();

        nffg.setName(NFFG.getName());

        Nodes nodes = new Nodes();

        for (NodeReader nodeReader : NFFG.getNodes()) {
            Node node = new Node();

            node.setName(nodeReader.getName());
            node.setNameNffg(nodeReader.getNffg().getName());
            node.setNameVnf(nodeReader.getFuncType().getName());
            node.setAllocatedOn(nodeReader.getHost().getName());

            try {

                loadNeoNode(node);
            } catch (ServiceException S) {
                S.printStackTrace();
            }


            nodes.getNode().add(node);

            incomingLinks.put(nodeReader.getName(), new CopyOnWriteArrayList<>());
            outgoingLinks.put(nodeReader.getName(), new CopyOnWriteArrayList<>());

            loadedNodes.put(node.getName(), node);
            incrementNode.incrementAndGet();
        }


        nffg.setDeployTime(getXMLGregorianCalendarNow());
        nffg.setNodes(nodes);

        loadedNffgs.put(NFFG.getName(), nffg);

        loadLinks(NFFG);

        incrementNffg.incrementAndGet();
    }

    private void loadLinks(NffgReader NFFG) {

        Links links = new Links();

        for (NodeReader nodeReader : NFFG.getNodes()) {
            for (LinkReader linkReader : nodeReader.getLinks()) {
                Link link = new Link();
                link.setName(nodeReader.getName() + "_" + linkReader.getDestinationNode().getName());
                link.setSrc(linkReader.getSourceNode().getName());
                link.setDst(linkReader.getDestinationNode().getName());
                link.setMaxLatency(BigInteger.valueOf(linkReader.getLatency()));
                link.setMinThroughput(linkReader.getThroughput());

                loadedLinks.put(nodeReader.getName() + "_" + linkReader.getDestinationNode().getName(), link);

                links.getLink().add(link);

                try {
                    loadNeoLink(link);
                } catch (ServiceException S) {
                    S.printStackTrace();
                }

                outgoingLinks.get(linkReader.getSourceNode().getName()).add(link.getName());
                incomingLinks.get(linkReader.getDestinationNode().getName()).add(link.getName());

            }
        }
        loadedNffgs.get(NFFG.getName()).setLinks(links);
    }





    private XMLGregorianCalendar getXMLGregorianCalendarNow()
            throws DatatypeConfigurationException
    {
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();
        return datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
    }

    public void loadNeoNode(it.polito.dp2.NFV.sol3.service.xjc.Node nodex) throws ServiceException {
        it.polito.dp2.NFV.sol3.service.wjc.Node node = new it.polito.dp2.NFV.sol3.service.wjc.Node();

        Property property = new Property();
        property.setName("name");
        property.setValue(nodex.getName());

        Properties properties = new Properties();
        properties.getProperty().add(property);
        node.setProperties(properties);

        Response nodeResponse = target.path("/data/node/")
                .request("application/xml")
                .post(Entity.entity(node, MediaType.APPLICATION_XML));

        checkResponse(nodeResponse);

        String id = nodeResponse.readEntity(it.polito.dp2.NFV.sol3.service.wjc.Node.class).getId();

        neoNodeMap.put(nodex.getName(), id);

        Labels labels = new Labels();
        labels.getLabel().add("Node");

        Response res = target.path("/data/node/" + id
                + "/labels")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(labels, MediaType.APPLICATION_XML));

        checkResponse(res);


        if (!neoHostMap.containsKey(nodex.getAllocatedOn())) {
            loadNeoHost(loadedHosts.get(nodex.getAllocatedOn()));
        }

        Relationship relationship = new Relationship();
        relationship.setType("AllocatedOn");
        relationship.setDstNode(neoHostMap.get(nodex.getAllocatedOn()));
        relationship.setSrcNode(id);

        Response relationshipResponse = target.path("/data/node/" + id + "/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship, MediaType.APPLICATION_XML));

        checkResponse(relationshipResponse);

    }

    public void loadNeoHost(Host host) throws ServiceException {
        it.polito.dp2.NFV.sol3.service.wjc.Node node = new it.polito.dp2.NFV.sol3.service.wjc.Node();

        Property property = new Property();
        property.setName("name");
        property.setValue(host.getName());

        Properties properties = new Properties();
        properties.getProperty().add(property);

        node.setProperties(properties);

        Response hostResponse = target.path("/data/node/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(node, MediaType.APPLICATION_XML));


        checkResponse(hostResponse);


        String id = hostResponse.readEntity(it.polito.dp2.NFV.sol3.service.wjc.Node.class).getId();

        neoHostMap.put(host.getName(), id);

        allocatedNodes.put(host.getName(), new ArrayList<>());

        Labels labels = new Labels();
        labels.getLabel().add("Host");

        Response res = target.path("/data/node/" + id + "/labels")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(labels, MediaType.APPLICATION_XML));

        checkResponse(res);
    }

    public void loadNeoLink(Link link) throws ServiceException {
        Relationship relationship = new Relationship();
        relationship.setType("ForwardsTo");
        relationship.setSrcNode(neoNodeMap.get(link.getSrc()));
        relationship.setDstNode(neoNodeMap.get(link.getDst()));

        Response linkResponse = target.path("/data/node/" +
                neoNodeMap.get(link.getSrc()) + "/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship, MediaType.APPLICATION_XML));

        checkResponse(linkResponse);
    }

    private static URI getBaseURI() {
        return UriBuilder.fromUri(System.getProperty(
                "it.polito.dp2.NFV.lab3.Neo4JSimpleXMLURL",
                "http://localhost:8080/Neo4JSimpleXML/rest")).build();
    }

    public void checkResponse (Response res) throws ServiceException {

        switch (res.getStatus()) {
            case 800:
                throw new ServiceException("Bad Request");
            case 804:
                throw new ServiceException("Not Found");
            case 900:
                throw new ServiceException("Internal Server Error");
            default:
                break;
        }
    }


}
*/
