package it.polito.dp2.NFV.sol3.client1;

import it.polito.dp2.NFV.FunctionalType;
import it.polito.dp2.NFV.lab3.*;
import it.polito.dp2.NFV.lab3.DeployedNffg;
import it.polito.dp2.NFV.sol3.client1.wjc.*;

import javax.inject.Singleton;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.math.BigInteger;
import java.net.URI;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:24/02/2018
 */

public class Client1 implements it.polito.dp2.NFV.lab3.NfvClient {
    private WebTarget target;
    private Client client;
    private Map<String, HostReaderClass> hostsMap;
    private Map<String, VNFReaderClass> VNFsMap;
    private Map<String, NodeReaderClass> nodesMap;
    private Map<NodeDescriptor, String> descrMap;

    public Client1() {
        client = ClientBuilder.newClient();
         target = client.target(getBaseURI());

        hostsMap = new HashMap<>();
        VNFsMap = new HashMap<>();
        nodesMap = new HashMap<>();
        descrMap = new HashMap<>();

        loadCatalog();
        loadHosts();


    }

    private void loadCatalog() {
        it.polito.dp2.NFV.sol3.client1.wjc.VNFs vnfs;

        Response response = target.path("/service/catalog")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        vnfs = response.readEntity(it.polito.dp2.NFV.sol3.client1.wjc.VNFs.class);

        for (it.polito.dp2.NFV.sol3.client1.wjc.VNF VNF : vnfs.getVNF()) {
            it.polito.dp2.NFV.sol3.client1.VNFReaderClass VNFreader = new it.polito.dp2.NFV.sol3.client1.VNFReaderClass();
            VNFreader.setName(VNF.getName());
            VNFreader.setFunctional_type(FunctionalType.fromValue(VNF.getType()));
            VNFreader.setRequiredMemory(VNF.getMemoryAmount().intValue());
            VNFreader.setRequiredStorage(VNF.getDiskStorage().intValue());

            VNFsMap.put(VNFreader.getName(), VNFreader);
        }

    }

    private void loadHosts() {
        it.polito.dp2.NFV.sol3.client1.wjc.Hosts hosts;

        Response response = target.path("/service/hosts")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        hosts = response.readEntity(it.polito.dp2.NFV.sol3.client1.wjc.Hosts.class);

        for (it.polito.dp2.NFV.sol3.client1.wjc.Host host : hosts.getHost()) {
            it.polito.dp2.NFV.sol3.client1.HostReaderClass hostReaderClass = new it.polito.dp2.NFV.sol3.client1.HostReaderClass();
            hostReaderClass.setName(host.getName());
            hostReaderClass.setAvailableMemory(host.getMemoryAmount().intValue());
            hostReaderClass.setAvailableStorage(host.getDiskStorage().intValue());
            hostReaderClass.setMaxVNFs(host.getMaxNumberVFN().intValue());
            hostsMap.put(hostReaderClass.getName(), hostReaderClass);
        }

    }




    @Override
    public DeployedNffg deployNffg(NffgDescriptor descriptor) throws AllocationException, ServiceException {
        NFFG nffg = new NFFG();


        Response response = target.path("/service/nffgs")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(nffg, MediaType.APPLICATION_XML));


        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }


        nffg = response.readEntity(NFFG.class);

        Calendar calendar = nffg.getDeployTime().toGregorianCalendar();

        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(calendar.getTimeZone());
        cal.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
        cal.set(Calendar.MONTH, calendar.get(Calendar.MONTH));
        cal.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
        cal.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
        cal.set(Calendar.SECOND, calendar.get(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, calendar.get(Calendar.MILLISECOND));

        NffgReaderClass nffgReaderClass = new NffgReaderClass();

        nffgReaderClass.setDeployTime(cal);
        nffgReaderClass.setName(nffg.getName());


        for (NodeDescriptor nodeDescriptor : descriptor.getNodes()) {
            Node node = new Node();

            node.setNameVnf(nodeDescriptor.getFuncType().getName());
            node.setAllocatedOn(nodeDescriptor.getHostName());

            response = target.path("/service/nffgs/" + nffg.getName() + "/nodes")
                    .request(MediaType.APPLICATION_XML)
                    .post(Entity.entity(node, MediaType.APPLICATION_XML),Response.class);

            try {
                checkResponse(response);
            } catch (ServiceException e) {
                e.printStackTrace();
            }

            node = response.readEntity(Node.class);

            NodeReaderClass nodeReaderClass = new NodeReaderClass();

            nodeReaderClass.setName(node.getName());
            nodeReaderClass.setFunction_type(VNFsMap.get(node.getNameVnf()));
            nodeReaderClass.setHost(hostsMap.get(node.getAllocatedOn()));

            hostsMap.get(nodeReaderClass.getHost().getName()).setNode(nodeReaderClass);

            nodesMap.put(nodeReaderClass.getName(), nodeReaderClass);
            descrMap.put(nodeDescriptor, nodeReaderClass.getName());
            nffgReaderClass.setNode(nodeReaderClass);
        }


        for (NodeDescriptor nodeDescriptor : descriptor.getNodes()) {
            for (LinkDescriptor linkDescriptor : nodeDescriptor.getLinks()) {
                Link link = new Link();

                link.setSrc(descrMap.get(linkDescriptor.getSourceNode()));
                link.setDst(descrMap.get(linkDescriptor.getDestinationNode()));
                link.setMaxLatency(BigInteger.valueOf(linkDescriptor.getLatency()));
                link.setMinThroughput(linkDescriptor.getThroughput());

                response = target.path("/service/nffgs/" + nffg.getName() + "/links")
                        .request(MediaType.APPLICATION_XML)
                        .post(Entity.entity(link, MediaType.APPLICATION_XML),Response.class);

                try {
                    checkResponse(response);
                } catch (ServiceException e) {
                    e.printStackTrace();
                }

                link = response.readEntity(Link.class);

                LinkReaderClass linkReaderClass = new LinkReaderClass();

                linkReaderClass.setName(link.getName());
                linkReaderClass.setLatency(link.getMaxLatency().intValue());
                linkReaderClass.setThroughput(link.getMinThroughput());
                linkReaderClass.setSourceNode(nodesMap.get(link.getSrc()));
                linkReaderClass.setDestinationNode(nodesMap.get(link.getDst()));

                nodesMap.get(link.getSrc()).setLink(linkReaderClass);
                nodesMap.get(link.getSrc()).setNffg(nffgReaderClass);
                nodesMap.get(link.getDst()).setNffg(nffgReaderClass);

                nffgReaderClass.setNode(nodesMap.get(link.getSrc()));
                nffgReaderClass.setNode(nodesMap.get(link.getDst()));
            }
        }

        return new DeployedNffgClass(nffgReaderClass);
    }

    @Override
    public DeployedNffg getDeployedNffg(String name) throws UnknownEntityException, ServiceException {
        NFFG nffg;

        NffgReaderClass nffgReaderClass = new NffgReaderClass();

        Response response = target.path("/service/nffgs/" + name)
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        }

        nffg = response.readEntity(NFFG.class);

        Calendar calendar = nffg.getDeployTime().toGregorianCalendar();

        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(calendar.getTimeZone());
        cal.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
        cal.set(Calendar.MONTH, calendar.get(Calendar.MONTH));
        cal.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
        cal.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
        cal.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
        cal.set(Calendar.SECOND, calendar.get(Calendar.SECOND));
        cal.set(Calendar.MILLISECOND, calendar.get(Calendar.MILLISECOND));

        nffgReaderClass.setDeployTime(cal);
        nffgReaderClass.setName(nffg.getName());

        for (Node node : nffg.getNodes().getNode()) {
            NodeReaderClass nodeReaderClass = new NodeReaderClass();

            nodeReaderClass.setName(node.getName());
            nodeReaderClass.setFunction_type(VNFsMap.get(node.getNameVnf()));
            nodeReaderClass.setHost(hostsMap.get(node.getAllocatedOn()));

            hostsMap.get(nodeReaderClass.getHost().getName()).setNode(nodeReaderClass);

            nodesMap.put(nodeReaderClass.getName(), nodeReaderClass);
            nffgReaderClass.setNode(nodeReaderClass);
        }

        for (Link link : nffg.getLinks().getLink()) {
            LinkReaderClass linkReaderClass = new LinkReaderClass();

            linkReaderClass.setName(link.getName());
            linkReaderClass.setLatency(link.getMaxLatency().intValue());
            linkReaderClass.setThroughput(link.getMinThroughput());
            linkReaderClass.setSourceNode(nodesMap.get(link.getSrc()));
            linkReaderClass.setDestinationNode(nodesMap.get(link.getDst()));

            nodesMap.get(link.getSrc()).setLink(linkReaderClass);
            nodesMap.get(link.getSrc()).setNffg(nffgReaderClass);
            nodesMap.get(link.getDst()).setNffg(nffgReaderClass);
            hostsMap.get(linkReaderClass.getSourceNode().getHost().getName()).setNode(nodesMap.get(link.getSrc()));
            hostsMap.get(linkReaderClass.getDestinationNode().getHost().getName()).setNode(nodesMap.get(link.getDst()));

            nffgReaderClass.setNode(nodesMap.get(link.getSrc()));
            nffgReaderClass.setNode(nodesMap.get(link.getDst()));
        }

        return new DeployedNffgClass(nffgReaderClass);
    }

    private static URI getBaseURI() {
        return UriBuilder.fromUri(System.getProperty(
                "it.polito.dp2.NFV.lab3.URL",
                "http://localhost:8080/NfvDeployer/rest")).build();
    }

    private void checkResponse(Response response) throws ServiceException{
        switch (response.getStatus()) {
            case 400:
                throw new ServiceException("ServiceException: Bad Request on NfvDeployer service (Client1)");

            case 404:
                throw new ServiceException("ServiceException: Not Found on NfvDeployer service (Client1)");

            case 500:
                throw new ServiceException("ServiceException: Internal Server Error on NfvDeployer service (Client1)");

            default:
                break;
        }
    }
}