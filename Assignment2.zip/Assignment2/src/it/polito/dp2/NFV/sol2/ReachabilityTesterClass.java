package it.polito.dp2.NFV.sol2;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.lab2.*;

import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment2"
 * Date:02/12/2017
 */
public class ReachabilityTesterClass implements ReachabilityTester {
    private NfvReader monitor = null;
    private Set<NffgReader> reader = null;
    private Set<HostReader> h_reader = null;
    private ClientNfv clientNfv = null;
    private Set<String> loadedNffg;
    private Set<String> loadedHosts;
    private HashMap<String,String> loadedNodes;  //<Node_name , Node_ID>
    private HashMap<String,String> loadedHost ;  //<Host_name , Host_ID>
    private HashMap<String,HostReader> hostmap;  //<Host_id, HostReader>
    private Set<ExtendedNodeReader> extendedHost;


    /**
     * Constructor
     */
    protected ReachabilityTesterClass()  {
        hostmap= new HashMap<>();
        loadedNodes = new HashMap<>();
        loadedHost = new HashMap<>();
        loadedNffg = new HashSet<>();
        loadedHosts = new HashSet<>();
        extendedHost = new HashSet<>();
        NfvReaderFactory factory = NfvReaderFactory.newInstance();
        try {
            clientNfv = new ClientNfv();
            monitor = factory.newNfvReader();
        } catch (NfvReaderException e) {
            e.printStackTrace();
        }
    }

    /**
     * Load inside the graph the nodes and the hosts
     * @param nffgName	the name of the NF-FG for which nodes have to be loaded
     * @throws UnknownNameException thrown if nffgName is null or unknown inside the graph
     * @throws AlreadyLoadedException throw if the node or the nodes or the hosts are already present inside the graph
     * @throws ServiceException thrown if something goes wrong while sending request to the server
     */
    @Override
    public void loadGraph(String nffgName) throws UnknownNameException, AlreadyLoadedException, ServiceException {
        reader = monitor.getNffgs(null);
        h_reader= monitor.getHosts();

        if(nffgName == null )
            throw new UnknownNameException();

        if(loadedNodes.containsKey((nffgName))){
            throw new AlreadyLoadedException();
        }
        for(NffgReader nffgReader: reader) {
            if (nffgReader.getName().equals(nffgName)) {
                loadNffg(nffgName);
                loadHost(nffgName);
                return;
            }
        }
        throw new UnknownNameException();

    }

    /**
     * Get a set of Extended host reader and return it to the getReachableHosts method
     * @param nffgName	the name of the NF-FG for which nodes have to be returned
     * @return a set of ExtendedNodeReader
     * @throws UnknownNameException thrown if nffgName is null or unknown inside the graph
     */
    @Override
    public Set<ExtendedNodeReader> getExtendedNodes(String nffgName) throws UnknownNameException {
        if(nffgName == null)
            throw new UnknownNameException();

        if(!loadedNffg.contains(nffgName))
            throw new UnknownNameException();

        for (NffgReader nffg_r: reader) {
            if (nffgName.equals(nffg_r.getName())) {
                for (NodeReader nodeReader : nffg_r.getNodes()) {
                    ExtendedNodeReaderClass extendedNode = new ExtendedNodeReaderClass();
                    extendedNode.setId(loadedNodes.get(nodeReader.getName()));
                    extendedNode.setName(nodeReader.getName());
                    extendedNode.setLoadedHost(hostmap);
                    extendedHost.add(extendedNode);
                }
            }
        }
        return extendedHost;

    }

    /**
     *Check if the the current nffg has been already loaded or not inside the graph
     * @param nffgName the name of the NF-FG for which nodes have to be loaded
     * @return a boolean that express if is loaded or not
     * @throws ServiceException thrown if something goes wrong while sending request to the server
     */
    @Override
    public boolean isLoaded(String nffgName) throws UnknownNameException {
        if (nffgName == null)
            throw new UnknownNameException();

        for(NffgReader nffgReader: monitor.getNffgs(null)) {
            if (nffgReader.getName() == null)
                throw new UnknownNameException();
        }

        if (!loadedNffg.contains(nffgName) ) {
            return false;
        }
        else return true;
    }


    /**
     * The method load the nffg inside the graph with all the information needed
     * @param nffgName
     * @throws ServiceException
     */
    private void loadNffg(String nffgName) throws ServiceException {
        for(NffgReader nffg_r: reader) {
            if(nffgName.equals(nffg_r.getName())) {
                for (NodeReader nodeReader : nffg_r.getNodes()) {
                    Response response = clientNfv.insertNode(nodeReader.getName());
                    clientNfv.statusVerification(response.getStatus());
                    Node node = response.readEntity(Node.class);
                    loadedNodes.put(node.getProperties().getProperty().get(0).getValue(), node.getId());
                    Response response1 = clientNfv.insertLabel(node.getId(), "Node");
                    clientNfv.statusVerification(response1.getStatus());

                }

                String srcNodeId, destNodeId;
                for (NodeReader r : nffg_r.getNodes()) {
                    for (LinkReader l : r.getLinks()) {
                        srcNodeId = loadedNodes.get(l.getSourceNode().getName());
                        destNodeId = loadedNodes.get(l.getDestinationNode().getName());
                        if (srcNodeId == null || destNodeId == null) throw new ServiceException();
                        Response response = clientNfv.insertRelationshipFt(srcNodeId, destNodeId);
                        clientNfv.statusVerification(response.getStatus());
                    }
                }
                loadedNffg.add(nffg_r.getName());
            }

        }
    }


    /**
     * Load all the hosts inside the graph with all the information needed
     * @param nffgName	the name of the NF-FG for which nodes have to be loaded
     * @throws UnknownNameException thrown if nffgName is null or unknown inside the graph
     * @throws AlreadyLoadedException throw if the node or the nodes or the hosts are already present inside the graph
     * @throws ServiceException thrown if something goes wrong while sending request to the server
     */
    private void loadHost(String nffgName) throws ServiceException, UnknownNameException, AlreadyLoadedException {
        for (HostReader host_r : h_reader) {
            if (loadedHost.containsKey((host_r.getName()))) {
                throw new AlreadyLoadedException();
            }
            Response response = clientNfv.insertHost(host_r.getName());
            clientNfv.statusVerification(response.getStatus());
            Node node = response.readEntity(Node.class);
            loadedHost.put(node.getProperties().getProperty().get(0).getValue(), node.getId());
            Response response1 = clientNfv.insertLabel(node.getId(), "Host");
            clientNfv.statusVerification(response1.getStatus());
            hostmap.put(node.getId(), host_r);
            loadedHosts.add(host_r.getName());


            String srcNodeId;
            String destNodeId ;
            for (NffgReader nffg_r : reader) {
                if (nffg_r.getName().equals(nffgName)) {
                    for (NodeReader nodeReader : nffg_r.getNodes()) {
                        if(nodeReader.getHost().getName().equals(host_r.getName())) {
                            srcNodeId = loadedNodes.get(nodeReader.getName());
                            destNodeId = node.getId();
                            if (srcNodeId == null || destNodeId == null) throw new ServiceException();
                            Response response2 = clientNfv.insertRelationshipAo(srcNodeId, destNodeId);
                            clientNfv.statusVerification(response2.getStatus());
                        }
                    }

                }
            }
        }
    }

}