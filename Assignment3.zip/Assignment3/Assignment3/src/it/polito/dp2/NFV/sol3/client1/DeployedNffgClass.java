package it.polito.dp2.NFV.sol3.client1;

import it.polito.dp2.NFV.*;
import it.polito.dp2.NFV.lab3.*;
import it.polito.dp2.NFV.sol3.client1.wjc.Link;
import it.polito.dp2.NFV.sol3.client1.wjc.Node;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:01/03/2018
 */
public class DeployedNffgClass implements DeployedNffg {
    private it.polito.dp2.NFV.sol3.client1.NffgReaderClass nffgReader;
    private Map<String, HostReaderClass> hosts;
    private Map<String, it.polito.dp2.NFV.sol3.client1.VNFReaderClass> VNFs;
    private WebTarget target;

    public DeployedNffgClass(it.polito.dp2.NFV.sol3.client1.NffgReaderClass NFFGR) {
        this.nffgReader = NFFGR;

        Client client = ClientBuilder.newClient();
        target = client.target(getBaseURI());

        VNFs = new HashMap<>();
        hosts = new HashMap<>();

        loadHosts();

        loadCatalog();

    }

    private void loadCatalog() {
        it.polito.dp2.NFV.sol3.client1.wjc.VNFs vnfs;

        Response response = target.path("/service/catalog")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        } catch (LinkAlreadyPresentException e) {

        }

        vnfs = response.readEntity(it.polito.dp2.NFV.sol3.client1.wjc.VNFs.class);

        for (it.polito.dp2.NFV.sol3.client1.wjc.VNF VNF : vnfs.getVNF()) {
            it.polito.dp2.NFV.sol3.client1.VNFReaderClass VNFreader = new it.polito.dp2.NFV.sol3.client1.VNFReaderClass();
            VNFreader.setName(VNF.getName());
            VNFreader.setFunctional_type(FunctionalType.fromValue(VNF.getType()));
            VNFreader.setRequiredMemory(VNF.getMemoryAmount().intValue());
            VNFreader.setRequiredStorage(VNF.getDiskStorage().intValue());

            VNFs.put(VNFreader.getName(), VNFreader);
        }

    }

    private void loadHosts() {
        it.polito.dp2.NFV.sol3.client1.wjc.Hosts hosts;

        Response response = target.path("/service/hosts")
                .request(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .get();

        try {
            checkResponse(response);
        } catch (ServiceException e) {
            e.printStackTrace();
        } catch (LinkAlreadyPresentException e) {

        }

        hosts = response.readEntity(it.polito.dp2.NFV.sol3.client1.wjc.Hosts.class);

        for (it.polito.dp2.NFV.sol3.client1.wjc.Host host : hosts.getHost()) {
            it.polito.dp2.NFV.sol3.client1.HostReaderClass hostReaderClass = new it.polito.dp2.NFV.sol3.client1.HostReaderClass();
            hostReaderClass.setName(host.getName());
            hostReaderClass.setAvailableMemory(host.getMemoryAmount().intValue());
            hostReaderClass.setAvailableStorage(host.getDiskStorage().intValue());
            hostReaderClass.setMaxVNFs(host.getMaxNumberVFN().intValue());
            this.hosts.put(hostReaderClass.getName(), hostReaderClass);
        }

    }



    @Override
        public NodeReader addNode(VNFTypeReader type, String hostName) throws AllocationException, ServiceException {

                Node node = new Node();

                if (hostName != null) {
                    node.setAllocatedOn(hostName);
                }


                node.setNameVnf(type.getName());

                Response response = target.path("/service/nffgs/" + this.nffgReader.getName() + "/nodes")
                        .request(MediaType.APPLICATION_XML)
                        .post(Entity.entity(node, MediaType.APPLICATION_XML),Response.class);



                switch (response.getStatus()) {
                    case 400:
                        throw new ServiceException("ServiceException: Bad Request while adding Node");

                    case 404:
                        throw new ServiceException("ServiceException: Not Found while adding Node");

                    case 403:
                        throw new AllocationException("ServiceException: Problem during the allocation of the Node");

                    case 500:
                        throw new ServiceException("ServiceException: Internal Server Error while adding Node");

                    default:
                        break;
                }

                node = response.readEntity(Node.class);

                it.polito.dp2.NFV.sol3.client1.NodeReaderClass nodeReaderClass = new it.polito.dp2.NFV.sol3.client1.NodeReaderClass();

                nodeReaderClass.setName(node.getName());
                nodeReaderClass.setNffg(this.nffgReader);
                nodeReaderClass.setHost(this.hosts.get(node.getAllocatedOn()));
                nodeReaderClass.setFunction_type(this.VNFs.get(node.getNameVnf()));

                this.nffgReader.setNode(nodeReaderClass);

                return nodeReaderClass;
        }
    @Override
    public LinkReader addLink(NodeReader source, NodeReader dest, boolean overwrite) throws NoNodeException, LinkAlreadyPresentException, ServiceException {
            Link link = new Link();

            link.setSrc(source.getName());
            link.setDst(dest.getName());

            Response response;

            if (this.nffgReader.getNode(source.getName()) == null ||
                    this.nffgReader.getNode(dest.getName()) == null) {
                throw new NoNodeException();
            }

            if (overwrite) {
                response = target.path("/service/nffgs/" + this.nffgReader.getName() + "/links")
                        .queryParam("overwrite", "true")
                        .request(MediaType.APPLICATION_XML)
                        .post(Entity.entity(link, MediaType.APPLICATION_XML),Response.class);
            } else {
                response = target.path("/service/nffgs/" + this.nffgReader.getName() + "/links")
                        .queryParam("overwrite", "false")
                        .request(MediaType.APPLICATION_XML)
                        .post(Entity.entity(link, MediaType.APPLICATION_XML),Response.class);
            }




        checkResponse(response);

            link = response.readEntity(Link.class);

            it.polito.dp2.NFV.sol3.client1.LinkReaderClass linkReaderClass = new it.polito.dp2.NFV.sol3.client1.LinkReaderClass();

            linkReaderClass.setName(link.getName());
            linkReaderClass.setSourceNode(source);
            linkReaderClass.setDestinationNode(dest);


            this.nffgReader.getNode(source.getName()).getLinks().add(linkReaderClass);

            return linkReaderClass;
    }

    @Override
    public NffgReader getReader() throws ServiceException {
        return this.nffgReader;
    }


    private static URI getBaseURI() {
        return UriBuilder.fromUri(System.getProperty(
                "it.polito.dp2.NFV.lab3.URL",
                "http://localhost:8080/NfvDeployer/rest")).build();
    }


    private void checkResponse(Response R) throws ServiceException, LinkAlreadyPresentException{
        switch (R.getStatus()) {
            case 400:
                throw new ServiceException("ServiceException: Bad Request ");

            case 404:
                throw new ServiceException("ServiceException: Not Found");

            case 403:
                throw new LinkAlreadyPresentException("ServiceException: Link Already Present!");

            case 500:
                throw new ServiceException("ServiceException: Internal Server Error");

            default:
                break;
        }
    }
}
