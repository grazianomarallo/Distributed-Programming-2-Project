package it.polito.dp2.NFV.sol2;

import it.polito.dp2.NFV.HostReader;
import it.polito.dp2.NFV.LinkReader;
import it.polito.dp2.NFV.NffgReader;
import it.polito.dp2.NFV.VNFTypeReader;
import it.polito.dp2.NFV.lab2.ExtendedNodeReader;
import it.polito.dp2.NFV.lab2.NoGraphException;
import it.polito.dp2.NFV.lab2.ServiceException;

import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment2"
 * Date:07/12/2017
 */
public class ExtendedNodeReaderClass implements ExtendedNodeReader {
    VNFTypeReader vnfTypeReader;
    Set<LinkReader> links;
    HostReader hostReader;
    NffgReader nffgReader;
    Set<HostReader> hosts;
    HashMap<String,HostReader> loadedHost;
    String name;
    String id;
    ClientNfv clientNfv;

    protected ExtendedNodeReaderClass(){
        hosts = new HashSet<>();
        clientNfv = new ClientNfv();
    }

    /**
     * The method perform a get request to the server in order the retrieve all the reachable host from
     * the current node
     * @return  a set of HostReader
     * @throws NoGraphException
     * @throws ServiceException
     */
    @Override
    public Set<HostReader> getReachableHosts() throws NoGraphException, ServiceException {
        Response response= clientNfv.getNodeReachableFromNode(this.id);
        clientNfv.checkResponse(response.getStatus());
        Nodes reachNode = response.readEntity(Nodes.class);
        for (Nodes.Node node : reachNode.getNode()) {
            hosts.add(this.loadedHost.get(node.getId()));

        }
        return hosts;
    }

    @Override
    public VNFTypeReader getFuncType() {
        return this.vnfTypeReader;
    }

    @Override
    public Set<LinkReader> getLinks() {
        return this.links;
    }

    @Override
    public HostReader getHost() {
        return this.hostReader;
    }

    @Override
    public NffgReader getNffg() {
        return this.nffgReader;
    }

    @Override
    public String getName() {
        return this.name;
    }

    public void setLoadedHost(HashMap<String, HostReader> loadedHost) {
        this.loadedHost = loadedHost;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }


}
