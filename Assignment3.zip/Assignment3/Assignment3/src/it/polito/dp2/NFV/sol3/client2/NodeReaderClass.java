/**
 * 
 */
package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.*;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @author Graziano Marallo
 *
 */
public class NodeReaderClass implements NodeReader {


	/**
	 * Getter and Setters
	 */


	private VNFTypeReader function_type;
	private Map<String, LinkReader> links;
	private NffgReader nffg;
	private String name;
	private HostReader host;

	public NodeReaderClass() {
		links = new HashMap<>();
	}

	public void setHost(HostReader host) {
		this.host = host;
	}

	public void setFunction_type(VNFTypeReader function_type) {
		this.function_type = function_type;
	}

	public void setLink(LinkReader link) {
		this.links.put(link.getName(), link);
	}

	public void setNffg(NffgReader nffg) {
		this.nffg = nffg;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public VNFTypeReader getFuncType() {
		return this.function_type;
	}

	@Override
	public Set<LinkReader> getLinks() {
		Set<LinkReader> linkReaders = new HashSet<>();

		for (LinkReader linkReader : this.links.values()) {
			linkReaders.add(linkReader);
		}
		return linkReaders;
	}

	@Override
	public HostReader getHost() {
		return this.host;
	}

	@Override
	public NffgReader getNffg() {
		return this.nffg;
	}

	@Override
	public String getName() {
		return this.name;
	}
}
