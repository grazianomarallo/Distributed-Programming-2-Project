/**
 * 
 */
package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.LinkReader;
import it.polito.dp2.NFV.NodeReader;

/**
 * @author Graziano Marallo
 *
 */
public class LinkReaderClass implements LinkReader {
	private NodeReader sourceNode;
	private NodeReader destinationNode;
	private float throughput;
	private int latency;
	private String name;

	public LinkReaderClass() {

	}

	public void setSourceNode(NodeReader sourceNode) {
		this.sourceNode = sourceNode;
	}

	public void setDestinationNode(NodeReader destinationNode) {
		this.destinationNode = destinationNode;
	}

	public void setThroughput(float throughput) {
		this.throughput = throughput;
	}

	public void setLatency(int latency) {
		this.latency = latency;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public NodeReader getSourceNode() {
		return this.sourceNode;
	}

	@Override
	public NodeReader getDestinationNode() {
		return this.destinationNode;
	}

	@Override
	public float getThroughput() {
		return this.throughput;
	}

	@Override
	public int getLatency() {
		return this.latency;
	}

	@Override
	public String getName() {
		return this.name;
	}

}


