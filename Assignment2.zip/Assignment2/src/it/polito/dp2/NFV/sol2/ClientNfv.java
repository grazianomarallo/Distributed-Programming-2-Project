package it.polito.dp2.NFV.sol2;


import it.polito.dp2.NFV.lab2.NoGraphException;
import it.polito.dp2.NFV.lab2.ServiceException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import java.net.URI;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment2"
 * Date:04/12/2017
 */



public class ClientNfv {
    private Client client;
    private WebTarget webTarget;


    /**
     *  Constructror
     *
     */
    public ClientNfv() {
        client = ClientBuilder.newClient();
        webTarget = client.target(getBaseURI());
    }

    /**
     * Return the BaseUri through the UriBuilder
     * @return
     */
    private static URI getBaseURI() {
        String uri = System.getProperty("it.polito.dp2.NFV.lab2.URL");
        return UriBuilder.fromUri(uri).build();
    }

    /**
     * Post for insert a new Node
     * @param nameNffg
     * @return
     */
    public Response insertNode(String nameNffg) {
        Node node = new Node();
        Property property = new Property();
        Properties properties = new Properties();
        property.setName("name");
        property.setValue(nameNffg);
        properties.getProperty().add(property);
        node.setProperties(properties);
        return webTarget.path("data/node/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(node, MediaType.APPLICATION_XML), Response.class);
    }

    /**
     * Post for insert a new host
     * @param nameHost
     * @return
     */
    public Response insertHost(String nameHost) {
        Node node = new Node();
        Property property = new Property();
        Properties properties = new Properties();
        property.setName("name");
        property.setValue(nameHost);
        properties.getProperty().add(property);
        node.setProperties(properties);
        return webTarget.path("data/node/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(node, MediaType.APPLICATION_XML), Response.class);
    }

    /**
     * Post for insert a new label
     * @param nodeId
     * @param label
     * @return
     */
    public Response insertLabel(String nodeId, String label) {
        Labels labels = new Labels();
        Node node = new Node();
        labels.getLabel().add(label);
        node.setLabels(labels);
        return webTarget.path("data/node/"+nodeId+"/labels/")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(labels, MediaType.APPLICATION_XML),Response.class);
    }

    /**
     * Post for insert a new relationship beetween two nodes
     * @param srcNodeId
     * @param dstNodeId
     * @return
     */
    public Response insertRelationshipFt(String srcNodeId,String dstNodeId){
        Relationship relationship = new Relationship();
        relationship.setDstNode(dstNodeId);
        relationship.setType("ForwardTo");
        return webTarget.path("data/node/"+srcNodeId+"/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship,MediaType.APPLICATION_XML),Response.class);
    }

    /**
     * Post for insert a new relationship beetween two nodes
     * @param srcNodeId
     * @param dstNodeId
     * @return
     */

    public Response insertRelationshipAo(String srcNodeId,String dstNodeId){
        Relationship relationship = new Relationship();
        relationship.setDstNode(dstNodeId);
        relationship.setType("AllocatedOn");
        return webTarget.path("data/node/"+srcNodeId+"/relationships")
                .request(MediaType.APPLICATION_XML)
                .post(Entity.entity(relationship,MediaType.APPLICATION_XML),Response.class);
    }

    public Response getNodeReachableFromNode(String srcNodeId){
        return webTarget.path("data/node/"+srcNodeId+"/reachableNodes")
                //.queryParam("relationshipType" ,"AllocatedOn|ForwardTo")
                .queryParam("nodeLabel","Host")
                .request(MediaType.APPLICATION_XML)
                .get();
    }


    /**
     * Returns the current status response from server or throw the generated Exception
     * @param status
     * @throws ServiceException
     */
    public void statusVerification(int status) throws ServiceException {
        switch (status){
            case 200 : //System.out.println("Code 200 : OK");
                break;
            case 201 : //System.out.println("Code 201 : Created");
                break;
            case 204 :// System.out.println("Code 204 : No Content");
                break;
            case 400 : throw new ServiceException("Error code: 400 (Bad Request)");
            case 404 : throw new ServiceException("Error code: 404 (Not Found)");
            case 500 : throw new ServiceException("Error code: 500 (Internal Server Error)");

        }

    }

    /**
     * Return the current status response from server and it used in the method getReachableHosts in order
     * to check if the graph exists or not
     * @param status
     * @throws ServiceException
     * @throws NoGraphException
     */
    public void checkResponse(int status) throws ServiceException, NoGraphException {
        switch (status){
            case 400 : throw new ServiceException("Error code: 400 (Bad Request)");
            case 404 : throw new NoGraphException("Error code: 404 (Graph Not Found)");
            case 500 : throw new ServiceException("Error code: 500 (Internal Server Error)");

        }

    }

    /**
     * The following method have been implemented in order to have all the possible operation that are listed
     * in Neo4JSimpleXML but they're never used
     */
    /**
     * Get a node by the correspondent id
     * @param srcId
     * @return
     */
    public Response getNodeById(String srcId){
        return webTarget.path("data/node/"+srcId).request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get a property by a nodeId
     * @param srcId
     * @return
     */
    public Response getPropertyByNodeId(String srcId){
        return webTarget.path("data/node/"+srcId+"/properties").request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get a property by nodeId and the name of the property itself
     * @param srcId
     * @param property_name
     * @return
     */
    public Response getPropertyByNodeIdName(String srcId, String property_name){
        return webTarget.path("data/node/"+srcId+"/properties/"+property_name).request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get the lables by nodeId
     * @param srcId
     * @return
     */
    public Response getLabelsByNodeId(String srcId){
        return webTarget.path("data/node/"+srcId+"/labels").request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get the relationship by Id
     * @param relationshipId
     * @return
     */
    public Response getRelationshipsById(String relationshipId){
        return webTarget.path("data/relationships/"+relationshipId).request(MediaType.APPLICATION_XML).get();
    }

    /**
     * get all the relationships by using node ID
     * @param srcNodeId
     * @return
     */
    public Response getAllRelationshipsByNodeId(String srcNodeId){
        return webTarget.path("data/node/"+srcNodeId+"/relationships/all").request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get the IN relationships by ID
     * @param srcNodeId
     * @return
     */

    public Response getInRelationshipsById(String srcNodeId){
        return webTarget.path("data/node/"+srcNodeId+"/relationships/in").request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get the Out Relationships by ID
     * @param srcNodeId
     * @return
     */

    public Response getOutRelationshipsById(String srcNodeId){
        return webTarget.path("data/node/"+srcNodeId+"/relationships/out").request(MediaType.APPLICATION_XML).get();
    }

    /**
     * Get the reachable node from node by id
     * @param srcNodeId
     * @return
     */




}
