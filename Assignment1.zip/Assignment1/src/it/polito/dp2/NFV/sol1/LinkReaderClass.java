/**
 * 
 */
package it.polito.dp2.NFV.sol1;

import it.polito.dp2.NFV.LinkReader;
import it.polito.dp2.NFV.NodeReader;

/**
 * @author Graziano Marallo
 *
 */
public class LinkReaderClass implements LinkReader{
String name;
NodeReader dstNode, srcNode;
int latency,throughput;

/*
 * Getters and Setters
 * 
 */

@Override
public String getName() {

	return name;
}
@Override
public NodeReader getDestinationNode() {

	return dstNode;
}
@Override
public int getLatency() {
	return latency;
}
@Override
public NodeReader getSourceNode() {
	return srcNode;
}
@Override
public float getThroughput() {
	return throughput;
}

public NodeReader getDstNode() {
	return dstNode;
}

public void setDstNode(NodeReader dstNode) {
	this.dstNode = dstNode;
}



public void setSrcNode(NodeReader srcNode) {
	this.srcNode = srcNode;
}

public void setName(String name) {
	this.name = name;
}

public void setLatency(int latency) {
	this.latency = latency;
}

public void setThroughput(int throughput) {
	this.throughput = throughput;
}

	
	

}


