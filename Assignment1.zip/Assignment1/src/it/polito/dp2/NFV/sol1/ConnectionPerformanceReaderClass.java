/**
 * 
 */
package it.polito.dp2.NFV.sol1;

import it.polito.dp2.NFV.ConnectionPerformanceReader;

/**
 * @author Graziano Marallo created on 08 nov 2017
 *
 */
public class ConnectionPerformanceReaderClass implements ConnectionPerformanceReader {
	int latency;
	float throughput;
	String src,dst;

	@Override
	public int getLatency() {
		return latency;
	}

	@Override
	public float getThroughput() {
		return throughput;
	}

	public void setLatency(int latency) {
		this.latency = latency;
	}

	public void setThroughput(Float throughput) {
		this.throughput = throughput;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getDst() {
		return dst;
	}

	public void setDst(String dst) {
		this.dst = dst;
	}
}
