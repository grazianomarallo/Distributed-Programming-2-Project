package it.polito.dp2.NFV.sol2;

import it.polito.dp2.NFV.lab2.ReachabilityTester;
import it.polito.dp2.NFV.lab2.ReachabilityTesterException;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment2"
 * Date:02/12/2017
 */
public class ReachabilityTesterFactory extends it.polito.dp2.NFV.lab2.ReachabilityTesterFactory {
    @Override
    public ReachabilityTester newReachabilityTester() throws ReachabilityTesterException {
        if( new ReachabilityTesterClass() == null)
            throw new ReachabilityTesterException();
        else
        return new ReachabilityTesterClass();
    }
}
