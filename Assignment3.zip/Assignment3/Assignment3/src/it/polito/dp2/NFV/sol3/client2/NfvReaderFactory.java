package it.polito.dp2.NFV.sol3.client2;

import it.polito.dp2.NFV.NfvReader;
import it.polito.dp2.NFV.NfvReaderException;

/**
 * Created by Graziano Marallo S238159
 * Username:"grazianomarallo"
 * Project name:"Assignment3"
 * Date:25/02/2018
 */
public class NfvReaderFactory extends it.polito.dp2.NFV.NfvReaderFactory{


    @Override
    public NfvReader newNfvReader() throws NfvReaderException {

        return new Client2();
    }

    public static NfvReaderFactory newInstance(){
        return new NfvReaderFactory();
    }

}
